(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,16015,(e,a,t)=>{},98547,(e,a,t)=>{var s=e.i(47167);e.r(16015);var r=e.r(71645),i=r&&"object"==typeof r&&"default"in r?r:{default:r},n=void 0!==s.default&&s.default.env&&!0,o=function(e){return"[object String]"===Object.prototype.toString.call(e)},l=function(){function e(e){var a=void 0===e?{}:e,t=a.name,s=void 0===t?"stylesheet":t,r=a.optimizeForSpeed,i=void 0===r?n:r;c(o(s),"`name` must be a string"),this._name=s,this._deletedRulePlaceholder="#"+s+"-deleted-rule____{}",c("boolean"==typeof i,"`optimizeForSpeed` must be a boolean"),this._optimizeForSpeed=i,this._serverSheet=void 0,this._tags=[],this._injected=!1,this._rulesCount=0;var l="undefined"!=typeof window&&document.querySelector('meta[property="csp-nonce"]');this._nonce=l?l.getAttribute("content"):null}var a,t=e.prototype;return t.setOptimizeForSpeed=function(e){c("boolean"==typeof e,"`setOptimizeForSpeed` accepts a boolean"),c(0===this._rulesCount,"optimizeForSpeed cannot be when rules have already been inserted"),this.flush(),this._optimizeForSpeed=e,this.inject()},t.isOptimizeForSpeed=function(){return this._optimizeForSpeed},t.inject=function(){var e=this;if(c(!this._injected,"sheet already injected"),this._injected=!0,"undefined"!=typeof window&&this._optimizeForSpeed){this._tags[0]=this.makeStyleTag(this._name),this._optimizeForSpeed="insertRule"in this.getSheet(),this._optimizeForSpeed||(n||console.warn("StyleSheet: optimizeForSpeed mode not supported falling back to standard mode."),this.flush(),this._injected=!0);return}this._serverSheet={cssRules:[],insertRule:function(a,t){return"number"==typeof t?e._serverSheet.cssRules[t]={cssText:a}:e._serverSheet.cssRules.push({cssText:a}),t},deleteRule:function(a){e._serverSheet.cssRules[a]=null}}},t.getSheetForTag=function(e){if(e.sheet)return e.sheet;for(var a=0;a<document.styleSheets.length;a++)if(document.styleSheets[a].ownerNode===e)return document.styleSheets[a]},t.getSheet=function(){return this.getSheetForTag(this._tags[this._tags.length-1])},t.insertRule=function(e,a){if(c(o(e),"`insertRule` accepts only strings"),"undefined"==typeof window)return"number"!=typeof a&&(a=this._serverSheet.cssRules.length),this._serverSheet.insertRule(e,a),this._rulesCount++;if(this._optimizeForSpeed){var t=this.getSheet();"number"!=typeof a&&(a=t.cssRules.length);try{t.insertRule(e,a)}catch(a){return n||console.warn("StyleSheet: illegal rule: \n\n"+e+"\n\nSee https://stackoverflow.com/q/20007992 for more info"),-1}}else{var s=this._tags[a];this._tags.push(this.makeStyleTag(this._name,e,s))}return this._rulesCount++},t.replaceRule=function(e,a){if(this._optimizeForSpeed||"undefined"==typeof window){var t="undefined"!=typeof window?this.getSheet():this._serverSheet;if(a.trim()||(a=this._deletedRulePlaceholder),!t.cssRules[e])return e;t.deleteRule(e);try{t.insertRule(a,e)}catch(s){n||console.warn("StyleSheet: illegal rule: \n\n"+a+"\n\nSee https://stackoverflow.com/q/20007992 for more info"),t.insertRule(this._deletedRulePlaceholder,e)}}else{var s=this._tags[e];c(s,"old rule at index `"+e+"` not found"),s.textContent=a}return e},t.deleteRule=function(e){if("undefined"==typeof window)return void this._serverSheet.deleteRule(e);if(this._optimizeForSpeed)this.replaceRule(e,"");else{var a=this._tags[e];c(a,"rule at index `"+e+"` not found"),a.parentNode.removeChild(a),this._tags[e]=null}},t.flush=function(){this._injected=!1,this._rulesCount=0,"undefined"!=typeof window?(this._tags.forEach(function(e){return e&&e.parentNode.removeChild(e)}),this._tags=[]):this._serverSheet.cssRules=[]},t.cssRules=function(){var e=this;return"undefined"==typeof window?this._serverSheet.cssRules:this._tags.reduce(function(a,t){return t?a=a.concat(Array.prototype.map.call(e.getSheetForTag(t).cssRules,function(a){return a.cssText===e._deletedRulePlaceholder?null:a})):a.push(null),a},[])},t.makeStyleTag=function(e,a,t){a&&c(o(a),"makeStyleTag accepts only strings as second parameter");var s=document.createElement("style");this._nonce&&s.setAttribute("nonce",this._nonce),s.type="text/css",s.setAttribute("data-"+e,""),a&&s.appendChild(document.createTextNode(a));var r=document.head||document.getElementsByTagName("head")[0];return t?r.insertBefore(s,t):r.appendChild(s),s},a=[{key:"length",get:function(){return this._rulesCount}}],function(e,a){for(var t=0;t<a.length;t++){var s=a[t];s.enumerable=s.enumerable||!1,s.configurable=!0,"value"in s&&(s.writable=!0),Object.defineProperty(e,s.key,s)}}(e.prototype,a),e}();function c(e,a){if(!e)throw Error("StyleSheet: "+a+".")}var d=function(e){for(var a=5381,t=e.length;t;)a=33*a^e.charCodeAt(--t);return a>>>0},m={};function h(e,a){if(!a)return"jsx-"+e;var t=String(a),s=e+t;return m[s]||(m[s]="jsx-"+d(e+"-"+t)),m[s]}function u(e,a){"undefined"==typeof window&&(a=a.replace(/\/style/gi,"\\/style"));var t=e+a;return m[t]||(m[t]=a.replace(/__jsx-style-dynamic-selector/g,e)),m[t]}var f=function(){function e(e){var a=void 0===e?{}:e,t=a.styleSheet,s=void 0===t?null:t,r=a.optimizeForSpeed,i=void 0!==r&&r;this._sheet=s||new l({name:"styled-jsx",optimizeForSpeed:i}),this._sheet.inject(),s&&"boolean"==typeof i&&(this._sheet.setOptimizeForSpeed(i),this._optimizeForSpeed=this._sheet.isOptimizeForSpeed()),this._fromServer=void 0,this._indices={},this._instancesCounts={}}var a=e.prototype;return a.add=function(e){var a=this;void 0===this._optimizeForSpeed&&(this._optimizeForSpeed=Array.isArray(e.children),this._sheet.setOptimizeForSpeed(this._optimizeForSpeed),this._optimizeForSpeed=this._sheet.isOptimizeForSpeed()),"undefined"==typeof window||this._fromServer||(this._fromServer=this.selectFromServer(),this._instancesCounts=Object.keys(this._fromServer).reduce(function(e,a){return e[a]=0,e},{}));var t=this.getIdAndRules(e),s=t.styleId,r=t.rules;if(s in this._instancesCounts){this._instancesCounts[s]+=1;return}var i=r.map(function(e){return a._sheet.insertRule(e)}).filter(function(e){return -1!==e});this._indices[s]=i,this._instancesCounts[s]=1},a.remove=function(e){var a=this,t=this.getIdAndRules(e).styleId;if(function(e,a){if(!e)throw Error("StyleSheetRegistry: "+a+".")}(t in this._instancesCounts,"styleId: `"+t+"` not found"),this._instancesCounts[t]-=1,this._instancesCounts[t]<1){var s=this._fromServer&&this._fromServer[t];s?(s.parentNode.removeChild(s),delete this._fromServer[t]):(this._indices[t].forEach(function(e){return a._sheet.deleteRule(e)}),delete this._indices[t]),delete this._instancesCounts[t]}},a.update=function(e,a){this.add(a),this.remove(e)},a.flush=function(){this._sheet.flush(),this._sheet.inject(),this._fromServer=void 0,this._indices={},this._instancesCounts={}},a.cssRules=function(){var e=this,a=this._fromServer?Object.keys(this._fromServer).map(function(a){return[a,e._fromServer[a]]}):[],t=this._sheet.cssRules();return a.concat(Object.keys(this._indices).map(function(a){return[a,e._indices[a].map(function(e){return t[e].cssText}).join(e._optimizeForSpeed?"":"\n")]}).filter(function(e){return!!e[1]}))},a.styles=function(e){var a,t;return a=this.cssRules(),void 0===(t=e)&&(t={}),a.map(function(e){var a=e[0],s=e[1];return i.default.createElement("style",{id:"__"+a,key:"__"+a,nonce:t.nonce?t.nonce:void 0,dangerouslySetInnerHTML:{__html:s}})})},a.getIdAndRules=function(e){var a=e.children,t=e.dynamic,s=e.id;if(t){var r=h(s,t);return{styleId:r,rules:Array.isArray(a)?a.map(function(e){return u(r,e)}):[u(r,a)]}}return{styleId:h(s),rules:Array.isArray(a)?a:[a]}},a.selectFromServer=function(){return Array.prototype.slice.call(document.querySelectorAll('[id^="__jsx-"]')).reduce(function(e,a){return e[a.id.slice(2)]=a,e},{})},e}(),x=r.createContext(null);function p(){return new f}function b(){return r.useContext(x)}x.displayName="StyleSheetContext";var g=i.default.useInsertionEffect||i.default.useLayoutEffect,v="undefined"!=typeof window?p():void 0;function y(e){var a=v||b();return a&&("undefined"==typeof window?a.add(e):g(function(){return a.add(e),function(){a.remove(e)}},[e.id,String(e.dynamic)])),null}y.dynamic=function(e){return e.map(function(e){return h(e[0],e[1])}).join(" ")},t.StyleRegistry=function(e){var a=e.registry,t=e.children,s=r.useContext(x),n=r.useState(function(){return s||a||p()})[0];return i.default.createElement(x.Provider,{value:n},t)},t.createStyleRegistry=p,t.style=y,t.useStyleRegistry=b},37902,(e,a,t)=>{a.exports=e.r(98547).style},75254,e=>{"use strict";var a=e.i(71645);let t=e=>{let a=e.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,a,t)=>t?t.toUpperCase():a.toLowerCase());return a.charAt(0).toUpperCase()+a.slice(1)},s=(...e)=>e.filter((e,a,t)=>!!e&&""!==e.trim()&&t.indexOf(e)===a).join(" ").trim();var r={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};let i=(0,a.forwardRef)(({color:e="currentColor",size:t=24,strokeWidth:i=2,absoluteStrokeWidth:n,className:o="",children:l,iconNode:c,...d},m)=>(0,a.createElement)("svg",{ref:m,...r,width:t,height:t,stroke:e,strokeWidth:n?24*Number(i)/Number(t):i,className:s("lucide",o),...!l&&!(e=>{for(let a in e)if(a.startsWith("aria-")||"role"===a||"title"===a)return!0})(d)&&{"aria-hidden":"true"},...d},[...c.map(([e,t])=>(0,a.createElement)(e,t)),...Array.isArray(l)?l:[l]])),n=(e,r)=>{let n=(0,a.forwardRef)(({className:n,...o},l)=>(0,a.createElement)(i,{ref:l,iconNode:r,className:s(`lucide-${t(e).replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase()}`,`lucide-${e}`,n),...o}));return n.displayName=t(e),n};e.s(["default",()=>n],75254)},73375,63059,e=>{"use strict";var a=e.i(75254);let t=(0,a.default)("chevron-left",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);e.s(["ChevronLeft",()=>t],73375);let s=(0,a.default)("chevron-right",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);e.s(["ChevronRight",()=>s],63059)},56303,e=>{"use strict";var a=e.i(43476),t=e.i(37902),s=e.i(71645),r=e.i(73375),i=e.i(63059);let n=(0,e.i(75254).default)("search",[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]]);function o(){let[e,o]=(0,s.useState)(0),[l,c]=(0,s.useState)(!1),[d,m]=(0,s.useState)(!1);(0,s.useEffect)(()=>{m(!0)},[]);let h=[{image:"https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&w=1920&q=80",title:"Recycle for a Better Tomorrow",description:"Join us in making the world greener by recycling waste responsibly."},{image:"https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=1920&q=80",title:"Sustainable Solutions",description:"We provide sustainable waste management solutions for businesses."},{image:"https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=1920&q=80",title:"Protect the Environment",description:"Our mission is to minimize environmental impact through recycling."}];(0,s.useEffect)(()=>{let e=setInterval(()=>{u()},5e3);return()=>clearInterval(e)},[e]);let u=()=>{l||(c(!0),o(e=>e===h.length-1?0:e+1),setTimeout(()=>c(!1),500))};return(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 min-h-screen bg-gray-100",children:[(0,a.jsx)(t.default,{id:"ab7aac2c1ae004f3",children:"@keyframes fadeInUp{0%{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}@keyframes fadeInDown{0%{opacity:0;transform:translateY(-30px)}to{opacity:1;transform:translateY(0)}}@keyframes slideInLeft{0%{opacity:0;transform:translate(-50px)}to{opacity:1;transform:translate(0)}}@keyframes slideInRight{0%{opacity:0;transform:translate(50px)}to{opacity:1;transform:translate(0)}}@keyframes pulse{0%,to{transform:scale(1)}50%{transform:scale(1.05)}}@keyframes float{0%,to{transform:translateY(0)}50%{transform:translateY(-10px)}}@keyframes shimmer{0%{background-position:-1000px 0}to{background-position:1000px 0}}.animate-fade-in-up.jsx-ab7aac2c1ae004f3{animation:.8s ease-out forwards fadeInUp}.animate-fade-in-down.jsx-ab7aac2c1ae004f3{animation:.8s ease-out forwards fadeInDown}.animate-slide-in-left.jsx-ab7aac2c1ae004f3{animation:.8s ease-out forwards slideInLeft}.animate-slide-in-right.jsx-ab7aac2c1ae004f3{animation:.8s ease-out forwards slideInRight}.animate-float.jsx-ab7aac2c1ae004f3{animation:3s ease-in-out infinite float}.animate-pulse-slow.jsx-ab7aac2c1ae004f3{animation:2s ease-in-out infinite pulse}.hover-lift.jsx-ab7aac2c1ae004f3{transition:all .3s}.hover-lift.jsx-ab7aac2c1ae004f3:hover{transform:translateY(-8px);box-shadow:0 20px 40px #00000026}.gradient-overlay.jsx-ab7aac2c1ae004f3{background:linear-gradient(135deg,#14b8a6e6 0%,#0d9488cc 100%)}.glass-effect.jsx-ab7aac2c1ae004f3{-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);background:#fffffff2;border:1px solid #fff3}.text-gradient.jsx-ab7aac2c1ae004f3{-webkit-text-fill-color:transparent;background:linear-gradient(135deg,#14b8a6 0%,#0d9488 100%);-webkit-background-clip:text;background-clip:text}.shimmer-effect.jsx-ab7aac2c1ae004f3{background:linear-gradient(90deg,#0000,#fff6,#0000) 0 0/200% 100%;animation:2s infinite shimmer}.card-hover.jsx-ab7aac2c1ae004f3{transition:all .4s cubic-bezier(.4,0,.2,1)}.card-hover.jsx-ab7aac2c1ae004f3:hover{transform:translateY(-12px)scale(1.02);box-shadow:0 25px 50px #0003}.icon-bounce.jsx-ab7aac2c1ae004f3:hover{animation:.6s ease-in-out pulse}.stagger-1.jsx-ab7aac2c1ae004f3{animation-delay:.1s}.stagger-2.jsx-ab7aac2c1ae004f3{animation-delay:.2s}.stagger-3.jsx-ab7aac2c1ae004f3{animation-delay:.3s}.stagger-4.jsx-ab7aac2c1ae004f3{animation-delay:.4s}.stagger-5.jsx-ab7aac2c1ae004f3{animation-delay:.5s}.stagger-6.jsx-ab7aac2c1ae004f3{animation-delay:.6s}"}),(0,a.jsx)("nav",{className:"jsx-ab7aac2c1ae004f3 bg-white shadow-lg relative z-50 animate-fade-in-down",children:(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 flex justify-between items-center h-20",children:[(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 flex items-center space-x-2",children:(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 w-32 h-16 flex items-center justify-center",children:(0,a.jsx)("img",{src:"/logo-en.png",alt:"REC Logo",className:"jsx-ab7aac2c1ae004f3 h-12 w-auto object-contain"})})}),(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 hidden md:flex items-center space-x-8",children:[(0,a.jsxs)("a",{href:"#",className:"jsx-ab7aac2c1ae004f3 text-green-600 font-medium relative group",children:["HOME",(0,a.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-0 left-0 w-full h-0.5 bg-green-600 transform origin-left"})]}),(0,a.jsxs)("a",{href:"#",className:"jsx-ab7aac2c1ae004f3 text-gray-600 hover:text-green-600 transition-all duration-300 relative group",children:["ABOUT",(0,a.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-0 left-0 w-0 h-0.5 bg-green-600 group-hover:w-full transition-all duration-300"})]}),(0,a.jsxs)("a",{href:"#",className:"jsx-ab7aac2c1ae004f3 text-gray-600 hover:text-green-600 transition-all duration-300 relative group",children:["SERVICES",(0,a.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-0 left-0 w-0 h-0.5 bg-green-600 group-hover:w-full transition-all duration-300"})]}),(0,a.jsxs)("a",{href:"#",className:"jsx-ab7aac2c1ae004f3 text-gray-600 hover:text-green-600 transition-all duration-300 relative group",children:["ELEMENTS",(0,a.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-0 left-0 w-0 h-0.5 bg-green-600 group-hover:w-full transition-all duration-300"})]}),(0,a.jsxs)("a",{href:"#",className:"jsx-ab7aac2c1ae004f3 text-gray-600 hover:text-green-600 transition-all duration-300 relative group",children:["BLOG",(0,a.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-0 left-0 w-0 h-0.5 bg-green-600 group-hover:w-full transition-all duration-300"})]}),(0,a.jsxs)("a",{href:"#",className:"jsx-ab7aac2c1ae004f3 text-gray-600 hover:text-green-600 transition-all duration-300 relative group",children:["CONTACT",(0,a.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-0 left-0 w-0 h-0.5 bg-green-600 group-hover:w-full transition-all duration-300"})]}),(0,a.jsx)("button",{className:"jsx-ab7aac2c1ae004f3 bg-green-500 hover:bg-green-600 text-white px-3 py-2 rounded font-medium transition-all duration-300 transform hover:scale-105 hover:shadow-lg relative overflow-hidden group flex items-center justify-center",children:(0,a.jsx)(n,{className:"w-6 h-6"})})]})]})})}),(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 relative h-[700px] overflow-hidden",children:[(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 absolute inset-0",children:h.map((t,s)=>(0,a.jsxs)("div",{className:`jsx-ab7aac2c1ae004f3 absolute inset-0 transition-all duration-700 ease-in-out ${s===e?"opacity-100 scale-100":"opacity-0 scale-105"}`,children:[(0,a.jsx)("img",{src:t.image,alt:t.title,style:{transform:s===e?"scale(1)":"scale(1.1)"},className:"jsx-ab7aac2c1ae004f3 w-full h-full object-cover transform transition-transform duration-700"}),(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 absolute inset-0 bg-gradient-to-r from-black/50 to-black/30"}),(0,a.jsxs)("div",{className:`jsx-ab7aac2c1ae004f3 absolute left-8 sm:left-16 top-1/3 glass-effect rounded-xl p-8 shadow-2xl max-w-md transform transition-all duration-700 delay-300 ${s===e?"translate-x-0 opacity-100":"-translate-x-20 opacity-0"}`,children:[(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 w-16 h-1 bg-linear-to-r from-green-600 to-teal-500 mb-4 rounded-full"}),(0,a.jsx)("h2",{className:"jsx-ab7aac2c1ae004f3 text-4xl font-bold text-gray-800 mb-4 leading-tight",children:(0,a.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 text-gradient",children:t.title})}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-700 text-lg leading-relaxed mb-6",children:t.description}),(0,a.jsxs)("button",{className:"jsx-ab7aac2c1ae004f3 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-xl relative overflow-hidden group",children:[(0,a.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 relative z-10",children:"LEARN MORE"}),(0,a.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 absolute inset-0 bg-white/20 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300"})]})]})]},s))}),(0,a.jsx)("button",{onClick:()=>{l||(c(!0),o(e=>0===e?h.length-1:e-1),setTimeout(()=>c(!1),500))},disabled:l,className:"jsx-ab7aac2c1ae004f3 absolute left-4 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/90 hover:bg-white backdrop-blur-sm rounded-full flex items-center justify-center z-30 transition-all duration-300 hover:scale-110 hover:shadow-xl disabled:opacity-50 group",children:(0,a.jsx)(r.ChevronLeft,{className:"w-7 h-7 text-gray-700 group-hover:text-green-600 transition-colors"})}),(0,a.jsx)("button",{onClick:u,disabled:l,className:"jsx-ab7aac2c1ae004f3 absolute right-4 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/90 hover:bg-white backdrop-blur-sm rounded-full flex items-center justify-center z-30 transition-all duration-300 hover:scale-110 hover:shadow-xl disabled:opacity-50 group",children:(0,a.jsx)(i.ChevronRight,{className:"w-7 h-7 text-gray-700 group-hover:text-green-600 transition-colors"})}),(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-3 z-30",children:h.map((t,s)=>(0,a.jsx)("button",{onClick:()=>{l||(c(!0),o(s),setTimeout(()=>c(!1),500))},className:`jsx-ab7aac2c1ae004f3 h-2 rounded-full transition-all ${s===e?"w-12 bg-white":"w-2 bg-white/50 hover:bg-white/75"}`},s))})]}),(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 relative -mt-32 z-20",children:(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 grid grid-cols-1 md:grid-cols-3 gap-6 shadow-2xl",children:[(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 bg-linear-to-br from-teal-500 to-teal-600 text-white p-8 hover:from-teal-600 hover:to-teal-700 transition-all duration-300 rounded-xl transform hover:-translate-y-2 hover:shadow-2xl cursor-pointer",children:[(0,a.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold mb-2",children:"INDUSTRIAL"}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 italic text-lg mb-4 opacity-90",children:"Waste Management"}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-sm leading-relaxed opacity-90",children:"We offer complete industrial waste management services, from collection to recycling."})]}),(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 bg-white p-8 hover:bg-gray-50 transition-all duration-300 rounded-xl transform hover:-translate-y-2 hover:shadow-2xl cursor-pointer border-2 border-transparent hover:border-teal-500",children:[(0,a.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-teal-600 mb-2",children:"SUSTAINABLE"}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 italic text-lg text-gray-600 mb-4",children:"Business Solutions"}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-sm text-gray-700 leading-relaxed",children:"We help business adopt sustainable and environmentally responsible recycling practices."})]}),(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 bg-white p-8 hover:bg-gray-50 transition-all duration-300 rounded-xl transform hover:-translate-y-2 hover:shadow-2xl cursor-pointer border-2 border-transparent hover:border-teal-500",children:[(0,a.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-teal-600 mb-2",children:"ENVIRONMENTAL"}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 italic text-lg text-gray-600 mb-4",children:"Quality Services"}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-sm text-gray-700 leading-relaxed",children:"We focus on disposing of all waste sustainably and minimizing environmental impact."})]})]})})}),(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 py-20 bg-linear-to-b from-gray-50 to-white",children:(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center",children:[(0,a.jsxs)("div",{className:`jsx-ab7aac2c1ae004f3 ${d?"animate-slide-in-left":"opacity-0"}`,children:[(0,a.jsxs)("h2",{className:"jsx-ab7aac2c1ae004f3 text-4xl font-bold text-gray-800 mb-4",children:["Welcome to ",(0,a.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 text-gradient",children:"Recycle"})]}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-lg text-gray-600 mb-6 font-medium",children:"We are a Leading Global Waste Management Company, Committed to The Environment"}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 mb-8 leading-relaxed",children:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam massa ligula, aliquet euismod eleifend vitae, interdum ut mi. Praesent fringilla pharetra sapien sit amet semper. Nunc id massa ut mi tempus mattis ac eu lectus."}),(0,a.jsx)("button",{className:"jsx-ab7aac2c1ae004f3 border-2 border-teal-600 text-teal-600 px-8 py-3 rounded-lg hover:bg-teal-600 hover:text-white transition-all duration-300 font-semibold transform hover:scale-105 hover:shadow-lg",children:"OUR SERVICES"})]}),(0,a.jsxs)("div",{className:`jsx-ab7aac2c1ae004f3 relative group ${d?"animate-slide-in-right":"opacity-0"}`,children:[(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 absolute inset-0 bg-linear-to-r from-teal-400 to-green-500 rounded-xl transform rotate-3 group-hover:rotate-6 transition-transform duration-300"}),(0,a.jsx)("img",{src:h[0].image,alt:h[0].title,className:"jsx-ab7aac2c1ae004f3 relative w-full rounded-xl shadow-2xl transform -rotate-1 group-hover:rotate-0 transition-transform duration-300"}),(0,a.jsx)("button",{className:"jsx-ab7aac2c1ae004f3 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-all duration-300 group-hover:bg-teal-500 animate-pulse-slow",children:(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 w-0 h-0 border-t-8 border-t-transparent border-l-12 border-l-teal-600 border-b-8 border-b-transparent ml-1 group-hover:border-l-white transition-colors"})})]})]})})}),(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 py-20 bg-white relative overflow-hidden",children:[(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 absolute top-0 right-0 w-96 h-96 bg-teal-100 rounded-full filter blur-3xl opacity-20 -z-10"}),(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-0 left-0 w-96 h-96 bg-green-100 rounded-full filter blur-3xl opacity-20 -z-10"}),(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:[(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 text-center mb-16",children:[(0,a.jsxs)("h2",{className:"jsx-ab7aac2c1ae004f3 text-4xl font-bold text-gray-800 mb-4",children:["Services & ",(0,a.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 text-gradient",children:"Solutions"})]}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 italic max-w-4xl mx-auto text-lg",children:"We offer comprehensive recycling, industry-specific waste management, quality control & sustainability solutions for businesses and corporations."})]}),(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 grid grid-cols-1 md:grid-cols-3 gap-12",children:[(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 text-center group card-hover",children:[(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 inline-flex items-center justify-center w-24 h-24 mb-6 bg-gradient-to-br from-teal-100 to-green-100 rounded-2xl",children:(0,a.jsxs)("svg",{viewBox:"0 0 64 64",fill:"none",stroke:"currentColor",strokeWidth:"2",className:"jsx-ab7aac2c1ae004f3 w-12 h-12 text-teal-600",children:[(0,a.jsx)("path",{d:"M20 16 L28 8 L36 16 M32 12 L32 32",className:"jsx-ab7aac2c1ae004f3"}),(0,a.jsx)("rect",{x:"12",y:"28",width:"40",height:"28",rx:"2",className:"jsx-ab7aac2c1ae004f3"}),(0,a.jsx)("circle",{cx:"32",cy:"42",r:"6",className:"jsx-ab7aac2c1ae004f3"})]})}),(0,a.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-gray-800 mb-3 group-hover:text-teal-600 transition-colors",children:"Waste Collection"}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 text-sm leading-relaxed",children:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."})]}),(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 text-center group card-hover",children:[(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 inline-flex items-center justify-center w-24 h-24 mb-6 bg-gradient-to-br from-teal-100 to-green-100 rounded-2xl",children:(0,a.jsxs)("svg",{viewBox:"0 0 64 64",fill:"none",stroke:"currentColor",strokeWidth:"2",className:"jsx-ab7aac2c1ae004f3 w-12 h-12 text-teal-600",children:[(0,a.jsx)("path",{d:"M32 12 L42 22 L38 22 L38 32 L26 32 L26 22 L22 22 Z",className:"jsx-ab7aac2c1ae004f3"}),(0,a.jsx)("path",{d:"M16 38 L26 28 L26 32 L36 32 L36 42 L26 42 L26 38 Z",className:"jsx-ab7aac2c1ae004f3"}),(0,a.jsx)("path",{d:"M48 38 L48 42 L38 42 L38 32 L48 32 L48 36 L42 28 Z",className:"jsx-ab7aac2c1ae004f3"})]})}),(0,a.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-gray-800 mb-3 group-hover:text-teal-600 transition-colors",children:"Recycling Services"}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 text-sm leading-relaxed",children:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."})]}),(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 text-center group card-hover",children:[(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 inline-flex items-center justify-center w-24 h-24 mb-6 bg-gradient-to-br from-teal-100 to-green-100 rounded-2xl",children:(0,a.jsxs)("svg",{viewBox:"0 0 64 64",fill:"none",stroke:"currentColor",strokeWidth:"2",className:"jsx-ab7aac2c1ae004f3 w-12 h-12 text-teal-600",children:[(0,a.jsx)("path",{d:"M32 8 Q40 16 40 28 Q40 40 32 48 Q24 40 24 28 Q24 16 32 8 Z",className:"jsx-ab7aac2c1ae004f3"}),(0,a.jsx)("circle",{cx:"32",cy:"28",r:"4",className:"jsx-ab7aac2c1ae004f3"}),(0,a.jsx)("path",{d:"M28 36 L32 40 L36 36",className:"jsx-ab7aac2c1ae004f3"})]})}),(0,a.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-gray-800 mb-3 group-hover:text-teal-600 transition-colors",children:"Environmental"}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 text-sm leading-relaxed",children:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."})]}),(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 text-center group card-hover",children:[(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 inline-flex items-center justify-center w-24 h-24 mb-6 bg-gradient-to-br from-teal-100 to-green-100 rounded-2xl",children:(0,a.jsxs)("svg",{viewBox:"0 0 64 64",fill:"none",stroke:"currentColor",strokeWidth:"2",className:"jsx-ab7aac2c1ae004f3 w-12 h-12 text-teal-600",children:[(0,a.jsx)("circle",{cx:"32",cy:"32",r:"20",className:"jsx-ab7aac2c1ae004f3"}),(0,a.jsx)("path",{d:"M24 32 L30 38 L42 26",strokeWidth:"3",className:"jsx-ab7aac2c1ae004f3"})]})}),(0,a.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-gray-800 mb-3 group-hover:text-teal-600 transition-colors",children:"Quality Audits"}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 text-sm leading-relaxed",children:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."})]}),(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 text-center group card-hover",children:[(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 inline-flex items-center justify-center w-24 h-24 mb-6 bg-gradient-to-br from-teal-100 to-green-100 rounded-2xl",children:(0,a.jsxs)("svg",{viewBox:"0 0 64 64",fill:"none",stroke:"currentColor",strokeWidth:"2",className:"jsx-ab7aac2c1ae004f3 w-12 h-12 text-teal-600",children:[(0,a.jsx)("path",{d:"M32 48 Q28 44 28 38 Q28 32 32 28 Q36 32 36 38 Q36 44 32 48 Z",className:"jsx-ab7aac2c1ae004f3"}),(0,a.jsx)("path",{d:"M26 38 Q22 34 22 28 Q22 22 26 18",className:"jsx-ab7aac2c1ae004f3"}),(0,a.jsx)("path",{d:"M38 38 Q42 34 42 28 Q42 22 38 18",className:"jsx-ab7aac2c1ae004f3"})]})}),(0,a.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-gray-800 mb-3 group-hover:text-teal-600 transition-colors",children:"BIO Fuel Production"}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 text-sm leading-relaxed",children:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."})]}),(0,a.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 text-center group card-hover",children:[(0,a.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 inline-flex items-center justify-center w-24 h-24 mb-6 bg-gradient-to-br from-teal-100 to-green-100 rounded-2xl",children:(0,a.jsxs)("svg",{viewBox:"0 0 64 64",fill:"none",stroke:"currentColor",strokeWidth:"2",className:"jsx-ab7aac2c1ae004f3 w-12 h-12 text-teal-600",children:[(0,a.jsx)("path",{d:"M32 12 Q36 16 36 22 L36 32",className:"jsx-ab7aac2c1ae004f3"}),(0,a.jsx)("path",{d:"M24 20 Q28 16 32 16 Q36 16 40 20",className:"jsx-ab7aac2c1ae004f3"}),(0,a.jsx)("circle",{cx:"32",cy:"38",r:"8",className:"jsx-ab7aac2c1ae004f3"}),(0,a.jsx)("path",{d:"M28 46 L28 52 M36 46 L36 52",className:"jsx-ab7aac2c1ae004f3"})]})}),(0,a.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-gray-800 mb-3 group-hover:text-teal-600 transition-colors",children:"Sustainability"}),(0,a.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 text-sm leading-relaxed",children:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."})]})]})]})]})]})}e.s(["default",()=>o],56303)},72520,e=>{"use strict";let a=(0,e.i(75254).default)("arrow-right",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]);e.s(["ArrowRight",()=>a],72520)},74492,e=>{"use strict";var a=e.i(43476),t=e.i(71645),s=e.i(73375),r=e.i(63059),i=e.i(75254);let n=(0,i.default)("clock",[["path",{d:"M12 6v6l4 2",key:"mmk7yg"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]),o=(0,i.default)("tag",[["path",{d:"M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z",key:"vktsd0"}],["circle",{cx:"7.5",cy:"7.5",r:".5",fill:"currentColor",key:"kqv944"}]]);var l=e.i(72520);function c(){let[e,i]=t.default.useState(null),[c,d]=t.default.useState(0),m=[{date:"11/2025",category:"POST | FORMATS | RECYCLING",title:"Recycling basics",description:"Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi gravida fringilla neque sit amet sollicitudin. Duis aliquam dictum feugiat. Quisque...",readTime:"5 min read"},{date:"11/2025",category:"RECYCLING",title:"Waste Collection Today",description:"Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi gravida fringilla neque sit amet sollicitudin. Duis aliquam dictum feugiat. Quisque...",readTime:"3 min read"},{date:"11/2025",category:"RECYCLING",title:"How to Recycle Paper",description:"Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi gravida fringilla neque sit amet sollicitudin. Duis aliquam dictum feugiat. Quisque...",readTime:"4 min read"}];return(0,a.jsxs)("div",{className:"relative bg-gradient-to-br from-emerald-400 via-teal-500 to-green-500 min-h-screen overflow-hidden",children:[(0,a.jsx)("style",{children:`
        @keyframes float {
          0%, 100% { transform: translate(0, 0) scale(1); }
          33% { transform: translate(30px, -30px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
        }
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes shimmer {
          0% { background-position: -1000px 0; }
          100% { background-position: 1000px 0; }
        }
        @keyframes wave {
          0%, 100% { d: path("M0,40 Q120,0 240,40 T480,40 T720,40 T960,40 T1200,40 T1440,40 L1440,80 L0,80 Z"); }
          50% { d: path("M0,40 Q120,60 240,40 T480,40 T720,40 T960,40 T1200,40 T1440,40 L1440,80 L0,80 Z"); }
        }
        @keyframes fadeInScale {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        @keyframes glowPulse {
          0%, 100% { box-shadow: 0 0 20px rgba(16, 185, 129, 0.4), 0 0 40px rgba(16, 185, 129, 0.2); }
          50% { box-shadow: 0 0 30px rgba(16, 185, 129, 0.6), 0 0 60px rgba(16, 185, 129, 0.3); }
        }
        @keyframes borderGlow {
          0%, 100% { border-color: rgba(16, 185, 129, 0.5); }
          50% { border-color: rgba(16, 185, 129, 1); }
        }
        @keyframes gradientShift {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        @keyframes ripple {
          0% { transform: scale(0); opacity: 1; }
          100% { transform: scale(4); opacity: 0; }
        }
        @keyframes slideInLeft {
          from { opacity: 0; transform: translateX(-50px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes slideInRight {
          from { opacity: 0; transform: translateX(50px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        @keyframes rotate {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        
        .animate-float { animation: float 20s ease-in-out infinite; }
        .animate-float-delayed { animation: float 25s ease-in-out infinite 5s; }
        .animate-float-slow { animation: float 30s ease-in-out infinite 10s; }
        .animate-slide-up { animation: slideUp 0.6s ease-out forwards; opacity: 0; }
        .animate-slide-in-left { animation: slideInLeft 0.8s ease-out forwards; }
        .animate-slide-in-right { animation: slideInRight 0.8s ease-out forwards; }
        .anim-delay-100 { animation-delay: 0.1s; }
        .anim-delay-200 { animation-delay: 0.2s; }
        .anim-delay-300 { animation-delay: 0.3s; }
        .anim-delay-400 { animation-delay: 0.4s; }
        
        .shimmer-btn {
          background: linear-gradient(90deg, #a3e635 0%, #bef264 50%, #a3e635 100%);
          background-size: 200% 100%;
          animation: shimmer 3s linear infinite;
        }
        
        .card-hover {
          transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
          position: relative;
          overflow: hidden;
        }
        
        .card-hover::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
          transition: left 0.5s;
        }
        
        .card-hover:hover::before {
          left: 100%;
        }
        
        .card-hover::after {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(20, 184, 166, 0.1));
          opacity: 0;
          transition: opacity 0.4s;
        }
        
        .card-hover:hover::after {
          opacity: 1;
        }
        
        .card-hover:hover {
          transform: translateY(-16px) scale(1.03);
          box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.3), 0 0 0 4px rgba(16, 185, 129, 0.2);
        }
        
        .wave-animate path {
          animation: wave 8s ease-in-out infinite;
        }
        
        .date-badge {
          position: relative;
          display: inline-block;
          background: linear-gradient(135deg, #10b981, #14b8a6);
          background-size: 200% 200%;
          animation: gradientShift 3s ease infinite;
        }
        
        .category-badge {
          position: relative;
          overflow: hidden;
        }
        
        .category-badge::before {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          width: 0;
          height: 0;
          background: rgba(255, 255, 255, 0.3);
          border-radius: 50%;
          transform: translate(-50%, -50%);
          transition: width 0.6s, height 0.6s;
        }
        
        .card-hover:hover .category-badge::before {
          width: 200px;
          height: 200px;
        }
        
        .btn-arrow {
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          position: relative;
          overflow: hidden;
        }
        
        .btn-arrow::before {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          width: 0;
          height: 0;
          background: rgba(16, 185, 129, 0.2);
          border-radius: 50%;
          transform: translate(-50%, -50%);
          transition: width 0.4s, height 0.4s;
        }
        
        .btn-arrow:hover::before {
          width: 150px;
          height: 150px;
        }
        
        .btn-arrow:hover {
          transform: scale(1.15) rotate(5deg);
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
          background: rgba(255, 255, 255, 0.95);
        }
        
        .btn-arrow:active {
          transform: scale(0.95) rotate(-5deg);
        }
        
        .learn-more-btn {
          position: relative;
          overflow: hidden;
        }
        
        .learn-more-btn::before {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          width: 0;
          height: 0;
          background: rgba(255, 255, 255, 0.2);
          border-radius: 50%;
          transform: translate(-50%, -50%);
          transition: width 0.6s, height 0.6s;
        }
        
        .learn-more-btn:hover::before {
          width: 300px;
          height: 300px;
        }
        
        .title-gradient {
          background: linear-gradient(135deg, #ffffff, #f0fdf4);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: gradientShift 4s ease infinite;
          background-size: 200% 200%;
        }
        
        .glow-text {
          text-shadow: 0 0 20px rgba(255, 255, 255, 0.5), 0 0 40px rgba(255, 255, 255, 0.3);
        }
        
        .card-corner {
          position: absolute;
          width: 0;
          height: 0;
          border-style: solid;
          transition: all 0.4s;
        }
        
        .card-corner-tl {
          top: 0;
          left: 0;
          border-width: 0 0 0 0;
          border-color: transparent transparent transparent #10b981;
        }
        
        .card-hover:hover .card-corner-tl {
          border-width: 40px 0 0 40px;
        }
        
        .card-corner-br {
          bottom: 0;
          right: 0;
          border-width: 0 0 0 0;
          border-color: transparent #10b981 transparent transparent;
        }
        
        .card-hover:hover .card-corner-br {
          border-width: 0 40px 40px 0;
        }
        
        .icon-float {
          animation: bounce 2s ease-in-out infinite;
        }
        
        .icon-rotate {
          transition: transform 0.4s;
        }
        
        .card-hover:hover .icon-rotate {
          transform: rotate(360deg);
        }
      `}),(0,a.jsxs)("div",{className:"absolute inset-0 overflow-hidden",children:[(0,a.jsx)("div",{className:"absolute top-20 left-10 w-96 h-96 bg-teal-600/20 rounded-full blur-3xl animate-float"}),(0,a.jsx)("div",{className:"absolute top-40 right-20 w-80 h-80 bg-emerald-600/20 rounded-full blur-3xl animate-float-delayed"}),(0,a.jsx)("div",{className:"absolute bottom-20 left-1/3 w-96 h-96 bg-green-600/20 rounded-full blur-3xl animate-float-slow"}),(0,a.jsx)("div",{className:"absolute top-1/4 right-1/4 w-64 h-64 bg-white/5 rounded-full blur-2xl animate-float"}),(0,a.jsx)("div",{className:"absolute bottom-1/4 left-1/4 w-72 h-72 bg-white/5 rounded-full blur-2xl animate-float-delayed"})]}),(0,a.jsxs)("div",{className:"relative container mx-auto px-4 py-16 pb-32",children:[(0,a.jsxs)("div",{className:"text-center mb-16 animate-slide-up",children:[(0,a.jsx)("h2",{className:"text-white text-5xl md:text-6xl font-bold mb-6 drop-shadow-2xl title-gradient glow-text",children:"Latest Articles"}),(0,a.jsxs)("div",{className:"flex items-center justify-center gap-2 mb-6",children:[(0,a.jsx)("div",{className:"h-1 w-20 bg-white/50 rounded-full animate-slide-in-left"}),(0,a.jsx)("div",{className:"h-2 w-2 bg-white rounded-full icon-float"}),(0,a.jsx)("div",{className:"h-1 w-20 bg-white/50 rounded-full animate-slide-in-right"})]}),(0,a.jsx)("p",{className:"text-white/95 text-lg max-w-4xl mx-auto italic leading-relaxed drop-shadow-lg animate-slide-up anim-delay-200",children:"Lorem ipsum dolor sit amet, consectetuer. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit."})]}),(0,a.jsx)("div",{className:"grid md:grid-cols-3 gap-8 max-w-7xl mx-auto mb-12",children:m.map((e,t)=>(0,a.jsxs)("div",{onMouseEnter:()=>i(t),onMouseLeave:()=>i(null),className:`bg-white p-8 rounded-lg shadow-2xl card-hover animate-slide-up ${1===t?"anim-delay-100":2===t?"anim-delay-200":""}`,children:[(0,a.jsx)("div",{className:"card-corner card-corner-tl"}),(0,a.jsx)("div",{className:"card-corner card-corner-br"}),(0,a.jsxs)("div",{className:"mb-6 relative z-10",children:[(0,a.jsxs)("div",{className:"flex items-center gap-3 mb-3",children:[(0,a.jsxs)("span",{className:"date-badge text-white text-xs font-bold uppercase px-3 py-1 rounded-full",children:[(0,a.jsx)(n,{className:"w-3 h-3 inline mr-1"}),e.date]}),(0,a.jsx)("span",{className:"text-gray-400 text-xs",children:e.readTime})]}),(0,a.jsxs)("div",{className:"category-badge inline-block bg-emerald-50 text-emerald-600 text-xs uppercase tracking-wide px-3 py-1 rounded-full font-semibold",children:[(0,a.jsx)(o,{className:"w-3 h-3 inline mr-1 icon-rotate"}),e.category]})]}),(0,a.jsx)("h3",{className:"text-gray-800 text-2xl font-bold mb-4 transition-all duration-300 hover:text-emerald-600 relative z-10 leading-tight",children:e.title}),(0,a.jsx)("p",{className:"text-gray-600 text-sm leading-relaxed mb-6 relative z-10",children:e.description}),(0,a.jsxs)("button",{className:"learn-more-btn bg-emerald-500 text-white px-6 py-3 rounded-full text-sm font-semibold uppercase hover:bg-emerald-600 transition-all duration-300 hover:shadow-xl hover:scale-105 active:scale-95 flex items-center gap-2 group relative z-10",children:["LEARN MORE",(0,a.jsx)(l.ArrowRight,{className:"w-4 h-4 transition-transform duration-300 group-hover:translate-x-2"})]})]},t))}),(0,a.jsxs)("div",{className:"flex justify-center gap-4 max-w-6xl mx-auto animate-slide-up anim-delay-300",children:[(0,a.jsx)("button",{onClick:()=>{d(e=>e>0?e-1:m.length-1)},className:"btn-arrow bg-white p-4 rounded-full hover:bg-gray-50 transition-all duration-300 shadow-lg relative z-10",children:(0,a.jsx)(s.ChevronLeft,{className:"w-6 h-6 text-gray-700"})}),(0,a.jsx)("button",{onClick:()=>{d(e=>e<m.length-1?e+1:0)},className:"btn-arrow bg-white p-4 rounded-full hover:bg-gray-50 transition-all duration-300 shadow-lg relative z-10",children:(0,a.jsx)(r.ChevronRight,{className:"w-6 h-6 text-gray-700"})})]}),(0,a.jsx)("div",{className:"flex justify-center gap-2 mt-8 animate-slide-up anim-delay-400",children:m.map((e,t)=>(0,a.jsx)("button",{onClick:()=>d(t),className:`h-2 rounded-full transition-all duration-300 ${c===t?"w-8 bg-white":"w-2 bg-white/50 hover:bg-white/75"}`},t))})]}),(0,a.jsx)("div",{className:"absolute bottom-0 left-0 right-0",children:(0,a.jsx)("svg",{className:"w-full h-20 wave-animate",viewBox:"0 0 1440 80",preserveAspectRatio:"none",children:(0,a.jsx)("path",{d:"M0,40 Q120,0 240,40 T480,40 T720,40 T960,40 T1200,40 T1440,40 L1440,80 L0,80 Z",fill:"white"})})})]})}e.s(["default",()=>c],74492)},6545,e=>{"use strict";var a=e.i(43476),t=e.i(71645),s=e.i(73375),r=e.i(63059),i=e.i(75254);let n=(0,i.default)("user",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]]),o=(0,i.default)("calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]]),l=(0,i.default)("message-circle",[["path",{d:"M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",key:"1sd12s"}]]),c=(0,i.default)("music",[["path",{d:"M9 18V5l12-2v13",key:"1jmyc2"}],["circle",{cx:"6",cy:"18",r:"3",key:"fqmcym"}],["circle",{cx:"18",cy:"16",r:"3",key:"1hluhg"}]]),d=(0,i.default)("play",[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",key:"10ikf1"}]]),m=({image:e,title:s,author:i,date:c,comments:d,description:m,icon:h})=>{let[u,f]=(0,t.useState)(!1);return(0,a.jsxs)("div",{className:"bg-white rounded-lg shadow-md overflow-hidden group transition-all duration-500 hover:shadow-2xl card-float",onMouseEnter:()=>f(!0),onMouseLeave:()=>f(!1),children:[(0,a.jsxs)("div",{className:"relative h-56 overflow-hidden",children:[(0,a.jsx)("img",{src:e,alt:s,className:"w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"}),(0,a.jsx)("div",{className:"absolute inset-0 bg-linear-to-t from-black/60 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"}),h&&(0,a.jsx)("div",{className:"absolute inset-0 flex items-center justify-center",children:(0,a.jsx)("div",{className:`bg-white rounded-full p-4 shadow-lg transition-all duration-500 ${u?"scale-110 rotate-12":"scale-100"}`,children:(0,a.jsx)(h,{className:"w-8 h-8 text-green-600 transition-colors duration-300 group-hover:text-green-500"})})})]}),(0,a.jsxs)("div",{className:"p-6",children:[(0,a.jsx)("h3",{className:"text-xl font-semibold text-gray-800 mb-4 transition-colors duration-300 group-hover:text-green-600",children:s}),(0,a.jsxs)("div",{className:"flex items-center gap-4 text-sm text-gray-600 mb-4",children:[(0,a.jsxs)("div",{className:"flex items-center gap-1 transition-transform duration-300 hover:scale-110",children:[(0,a.jsx)(n,{className:"w-4 h-4"}),(0,a.jsx)("span",{className:"text-green-600",children:i})]}),(0,a.jsxs)("div",{className:"flex items-center gap-1 transition-transform duration-300 hover:scale-110",children:[(0,a.jsx)(o,{className:"w-4 h-4"}),(0,a.jsx)("span",{children:c})]}),(0,a.jsxs)("div",{className:"flex items-center gap-1 transition-transform duration-300 hover:scale-110",children:[(0,a.jsx)(l,{className:"w-4 h-4"}),(0,a.jsx)("span",{children:d})]})]}),(0,a.jsx)("p",{className:"text-gray-600 leading-relaxed mb-4",children:m}),(0,a.jsxs)("button",{className:"text-green-600 font-medium flex items-center gap-2 transition-all duration-300 hover:gap-3 group/btn",children:["Continue",(0,a.jsx)(r.ChevronRight,{className:"w-4 h-4 transition-transform duration-300 group-hover/btn:translate-x-1"})]})]})]})};function h(){let[e,i]=(0,t.useState)(0),n=[{image:"https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=800&h=600&fit=crop",title:"Environment Perspective",author:"Johny Walker",date:"11/2025",comments:"0",description:"Mauris id enim id purus ornare tincidunt. Aenean vel consequat risus. Proin viverra nisi at nisl imperdiet auctor.",icon:null},{image:"https://images.unsplash.com/photo-1535083783855-76ae62b2914e?w=800&h=600&fit=crop",title:"New Ecological Bulbs",author:"Johny Walker",date:"11/2025",comments:"0",description:"Mauris id enim id purus ornare tincidunt. Aenean vel consequat risus. Proin viverra nisi at nisl imperdiet auctor.",icon:c},{image:"https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?w=800&h=600&fit=crop",title:"Protect The Environment",author:"Johny Walker",date:"11/2025",comments:"0",description:"Mauris id enim id purus ornare tincidunt. Aenean vel consequat risus. Proin viverra nisi at nisl imperdiet auctor.",icon:d}];return(0,a.jsxs)("div",{className:"bg-gray-50 py-16 px-4 relative overflow-hidden",children:[(0,a.jsx)("style",{children:`
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(40px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes cardFloat {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        @keyframes shimmerLine {
          0% { transform: scaleX(0); transform-origin: left; }
          50% { transform: scaleX(1); transform-origin: left; }
          51% { transform: scaleX(1); transform-origin: right; }
          100% { transform: scaleX(0); transform-origin: right; }
        }
        @keyframes pulse {
          0%, 100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(22, 163, 74, 0.4); }
          50% { transform: scale(1.05); box-shadow: 0 0 0 10px rgba(22, 163, 74, 0); }
        }
        @keyframes gradientMove {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        .card-float:hover { animation: cardFloat 2s ease-in-out infinite; }
        .title-animate { animation: fadeInUp 0.8s ease-out; }
        .underline-animate { animation: shimmerLine 2s ease-in-out infinite; }
        .nav-btn { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
        .nav-btn:not(:disabled):hover { animation: pulse 1s ease-in-out infinite; }
        .nav-btn:active { transform: scale(0.9); }
        .nav-btn:disabled { cursor: not-allowed; opacity: 0.3; }
        .bg-pattern { 
          background-image: 
            radial-gradient(circle at 20% 50%, rgba(22, 163, 74, 0.05) 0%, transparent 50%),
            radial-gradient(circle at 80% 80%, rgba(22, 163, 74, 0.05) 0%, transparent 50%);
        }
        .gradient-text {
          background: linear-gradient(135deg, #059669, #10b981, #34d399);
          background-size: 200% 200%;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: gradientMove 3s ease infinite;
        }
      `}),(0,a.jsx)("div",{className:"absolute inset-0 bg-pattern"}),(0,a.jsxs)("div",{className:"max-w-7xl mx-auto relative",children:[(0,a.jsxs)("div",{className:"flex items-center justify-between mb-12",children:[(0,a.jsx)("div",{className:"flex-1"}),(0,a.jsxs)("div",{className:"text-center title-animate",children:[(0,a.jsxs)("h2",{className:"text-4xl font-bold text-gray-800 mb-3",children:["LATEST ",(0,a.jsx)("span",{className:"gradient-text",children:"NEWS"})]}),(0,a.jsx)("div",{className:"relative h-1 w-16 mx-auto bg-gray-200 rounded-full overflow-hidden",children:(0,a.jsx)("div",{className:"absolute inset-0 bg-linear-to-r from-green-400 via-green-600 to-green-400 underline-animate"})})]}),(0,a.jsxs)("div",{className:"flex-1 flex justify-end gap-3",children:[(0,a.jsx)("button",{onClick:()=>i(Math.max(0,e-1)),className:"nav-btn bg-green-600 text-white p-3 rounded-full hover:bg-green-700 disabled:opacity-50 shadow-lg",disabled:0===e,children:(0,a.jsx)(s.ChevronLeft,{className:"w-5 h-5"})}),(0,a.jsx)("button",{onClick:()=>i(Math.min(n.length-3,e+1)),className:"nav-btn bg-green-600 text-white p-3 rounded-full hover:bg-green-700 disabled:opacity-50 shadow-lg",disabled:e>=n.length-3,children:(0,a.jsx)(r.ChevronRight,{className:"w-5 h-5"})})]})]}),(0,a.jsx)("div",{className:"overflow-hidden",children:(0,a.jsx)("div",{className:"flex transition-transform duration-700 ease-out",style:{transform:`translateX(-${33.333*e}%)`},children:n.map((e,t)=>(0,a.jsx)("div",{className:"w-1/3 shrink-0 px-3",style:{animation:`fadeInUp 0.6s ease-out ${.1*t}s both`},children:(0,a.jsx)(m,{...e})},t))})})]})]})}e.s(["default",()=>h],6545)},95415,e=>{"use strict";var a=e.i(43476),t=e.i(71645),s=e.i(75254);let r=(0,s.default)("leaf",[["path",{d:"M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z",key:"nnexq3"}],["path",{d:"M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12",key:"mt58a7"}]]),i=(0,s.default)("trending-up",[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]]),n=(0,s.default)("lightbulb",[["path",{d:"M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",key:"1gvzjb"}],["path",{d:"M9 18h6",key:"x1upvd"}],["path",{d:"M10 22h4",key:"ceow96"}]]),o=(0,s.default)("briefcase",[["path",{d:"M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16",key:"jecpp"}],["rect",{width:"20",height:"14",x:"2",y:"6",rx:"2",key:"i6l2r4"}]]),l=(0,s.default)("graduation-cap",[["path",{d:"M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",key:"j76jl0"}],["path",{d:"M22 10v6",key:"1lu8f3"}],["path",{d:"M6 12.5V16a6 3 0 0 0 12 0v-3.5",key:"1r8lef"}]]),c=(0,s.default)("users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]]),d=(0,s.default)("globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]]);var m=e.i(72520);let h=(0,s.default)("sparkles",[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]]),u=({icon:e,title:t,description:s,index:r})=>(0,a.jsxs)("div",{className:"flex gap-4 group cursor-pointer feature-card",style:{animationDelay:`${.1*r}s`},children:[(0,a.jsxs)("div",{className:"flex-shrink-0 pt-1 relative",children:[(0,a.jsxs)("div",{className:"icon-wrapper w-12 h-12 bg-gradient-to-br from-teal-500 to-emerald-500 rounded-xl flex items-center justify-center shadow-lg relative overflow-hidden",children:[(0,a.jsx)("div",{className:"absolute inset-0 bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"}),(0,a.jsx)("div",{className:"absolute inset-0 rounded-xl ripple-ring"}),(0,a.jsx)(e,{className:"w-5 h-5 text-white relative z-10 icon-bounce"}),(0,a.jsx)("div",{className:"absolute top-0 right-0 w-3 h-3 bg-white/30 rounded-bl-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"})]}),(0,a.jsx)("div",{className:"absolute top-14 left-1/2 transform -translate-x-1/2 w-0.5 h-full bg-gradient-to-b from-teal-200 to-transparent opacity-0 group-hover:opacity-50 transition-opacity duration-500"})]}),(0,a.jsxs)("div",{className:"flex-1 pb-2",children:[(0,a.jsxs)("h4",{className:"font-bold text-gray-800 text-base mb-2 group-hover:text-teal-600 transition-colors duration-300 flex items-center gap-2",children:[t,(0,a.jsx)(m.ArrowRight,{className:"w-4 h-4 opacity-0 group-hover:opacity-100 transform translate-x-0 group-hover:translate-x-1 transition-all duration-300"})]}),(0,a.jsx)("p",{className:"text-gray-600 text-sm leading-relaxed group-hover:text-gray-700 transition-colors duration-300",children:s})]})]});e.s(["default",0,()=>{let[e,s]=t.default.useState(null);return(0,a.jsxs)("div",{className:"py-20 bg-gradient-to-br from-gray-50 via-white to-teal-50/30 relative overflow-hidden",children:[(0,a.jsx)("style",{children:`
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes float {
          0%, 100% { transform: translate(0, 0) rotate(0deg); }
          33% { transform: translate(30px, -30px) rotate(5deg); }
          66% { transform: translate(-20px, 20px) rotate(-5deg); }
        }
        @keyframes pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.05); }
        }
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        @keyframes iconBounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-4px); }
        }
        @keyframes ripple {
          0% { transform: scale(0.8); opacity: 1; }
          100% { transform: scale(1.5); opacity: 0; }
        }
        @keyframes slideInLeft {
          from { opacity: 0; transform: translateX(-30px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes slideInRight {
          from { opacity: 0; transform: translateX(30px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }
        @keyframes gradientShift {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        @keyframes sparkle {
          0%, 100% { opacity: 0; transform: scale(0) rotate(0deg); }
          50% { opacity: 1; transform: scale(1) rotate(180deg); }
        }
        .feature-card {
          animation: fadeInUp 0.6s ease-out backwards;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .feature-card:hover {
          transform: translateX(8px);
        }
        .icon-wrapper {
          transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .feature-card:hover .icon-wrapper {
          transform: scale(1.1) rotate(5deg);
          box-shadow: 0 20px 25px -5px rgba(20, 184, 166, 0.4);
        }
        .icon-bounce {
          animation: iconBounce 2s ease-in-out infinite;
        }
        .ripple-ring {
          animation: ripple 2s cubic-bezier(0.4, 0, 0.2, 1) infinite;
        }
        .floating-shape {
          animation: float 20s ease-in-out infinite;
        }
        .floating-shape-delayed {
          animation: float 25s ease-in-out infinite 5s;
        }
        .floating-shape-slow {
          animation: float 30s ease-in-out infinite 10s;
        }
        .title-animate {
          animation: scaleIn 0.8s ease-out;
        }
        .subtitle-animate {
          animation: slideInLeft 0.8s ease-out 0.2s backwards;
        }
        .underline-animate {
          animation: slideInRight 0.8s ease-out 0.4s backwards;
        }
        .cta-animate {
          animation: fadeInUp 0.8s ease-out 0.6s backwards;
        }
        .gradient-text {
          background: linear-gradient(135deg, #14b8a6, #10b981, #14b8a6);
          background-size: 200% 200%;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: gradientShift 3s ease infinite;
        }
        .shimmer-effect {
          position: relative;
          overflow: hidden;
        }
        .shimmer-effect::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
          animation: shimmer 3s infinite;
        }
        .btn-primary {
          position: relative;
          overflow: hidden;
          transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .btn-primary::before {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          width: 0;
          height: 0;
          background: rgba(255, 255, 255, 0.2);
          border-radius: 50%;
          transform: translate(-50%, -50%);
          transition: width 0.6s, height 0.6s;
        }
        .btn-primary:hover::before {
          width: 300px;
          height: 300px;
        }
        .btn-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 20px 25px -5px rgba(20, 184, 166, 0.4);
        }
        .btn-secondary {
          position: relative;
          overflow: hidden;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .btn-secondary::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(20, 184, 166, 0.1), transparent);
          transition: left 0.5s;
        }
        .btn-secondary:hover::before {
          left: 100%;
        }
        .btn-secondary:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 20px -5px rgba(20, 184, 166, 0.2);
          border-color: #14b8a6;
        }
        .sparkle-icon {
          animation: sparkle 2s ease-in-out infinite;
        }
        .decorative-circle {
          position: absolute;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(20, 184, 166, 0.1), transparent);
        }
      `}),(0,a.jsxs)("div",{className:"absolute inset-0 overflow-hidden pointer-events-none",children:[(0,a.jsx)("div",{className:"absolute top-0 right-0 w-96 h-96 bg-teal-100 rounded-full opacity-20 blur-3xl floating-shape"}),(0,a.jsx)("div",{className:"absolute bottom-0 left-0 w-96 h-96 bg-green-100 rounded-full opacity-20 blur-3xl floating-shape-delayed"}),(0,a.jsx)("div",{className:"absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-100 rounded-full opacity-10 blur-3xl floating-shape-slow"}),(0,a.jsx)("div",{className:"decorative-circle",style:{width:"200px",height:"200px",top:"10%",left:"5%"}}),(0,a.jsx)("div",{className:"decorative-circle",style:{width:"150px",height:"150px",bottom:"15%",right:"8%"}})]}),(0,a.jsxs)("div",{className:"max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10",children:[(0,a.jsxs)("div",{className:"mb-16 text-center",children:[(0,a.jsxs)("div",{className:"flex items-center justify-center gap-2 mb-3 subtitle-animate",children:[(0,a.jsx)(h,{className:"w-4 h-4 text-teal-600 sparkle-icon"}),(0,a.jsx)("p",{className:"text-teal-600 italic font-medium",children:"Get to Know About Us"}),(0,a.jsx)(h,{className:"w-4 h-4 text-teal-600 sparkle-icon",style:{animationDelay:"1s"}})]}),(0,a.jsxs)("h2",{className:"text-5xl md:text-6xl font-bold text-gray-800 mb-4 title-animate",children:["Why ",(0,a.jsx)("span",{className:"gradient-text",children:"REC?"})]}),(0,a.jsxs)("div",{className:"flex items-center justify-center gap-3 underline-animate",children:[(0,a.jsx)("div",{className:"h-1 w-20 bg-gradient-to-r from-transparent to-teal-500 rounded-full"}),(0,a.jsx)("div",{className:"h-2 w-2 bg-teal-500 rounded-full"}),(0,a.jsx)("div",{className:"h-1 w-20 bg-gradient-to-l from-transparent to-teal-500 rounded-full"})]}),(0,a.jsx)("p",{className:"text-gray-600 mt-6 max-w-2xl mx-auto leading-relaxed subtitle-animate",style:{animationDelay:"0.3s"},children:"Discover what makes us the premier choice for environmental consultancy services"})]}),(0,a.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8 mb-12",children:[{icon:r,title:"Environmental Impact:",description:"REC play a crucial role in helping businesses minimize their environmental impact through expert advice and solutions.",index:0},{icon:i,title:"Sustainable Development:",description:"We assist clients in adopting sustainable practices, incorporating eco-friendly technologies and energy-efficient processes.",index:1},{icon:n,title:"Problem Solving:",description:"Our consultants assess environmental issues and develop innovative solutions to environmental challenges.",index:2},{icon:o,title:"Diverse Projects:",description:"We cover environmental impact assessments, site remediation, water resource management, and renewable energy projects.",index:3},{icon:l,title:"Educational Role:",description:"We educate clients about environmental issues and best practices, promoting environmental stewardship.",index:4},{icon:c,title:"Collaboration:",description:"We collaborate with experts from diverse fields, fostering a collaborative work environment for continuous learning.",index:5},{icon:d,title:"Global Relevance:",description:"We work on international projects, addressing environmental challenges and contributing to global sustainability efforts.",index:6}].map((e,t)=>(0,a.jsx)(u,{...e,index:t},t))}),(0,a.jsxs)("div",{className:"flex flex-col sm:flex-row gap-4 justify-center items-center cta-animate",children:[(0,a.jsxs)("button",{className:"btn-primary bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white px-8 py-3.5 rounded-xl font-semibold shadow-lg flex items-center gap-2 group relative z-10",onMouseEnter:()=>s("learn"),onMouseLeave:()=>s(null),children:[(0,a.jsx)("span",{className:"relative z-10",children:"Learn More"}),(0,a.jsx)(m.ArrowRight,{className:"w-5 h-5 relative z-10 transition-transform duration-300 group-hover:translate-x-1"})]}),(0,a.jsxs)("button",{className:"btn-secondary border-2 border-teal-600 text-teal-600 hover:text-teal-700 px-8 py-3.5 rounded-xl font-semibold flex items-center gap-2 group bg-white relative z-10",onMouseEnter:()=>s("contact"),onMouseLeave:()=>s(null),children:[(0,a.jsx)("span",{className:"relative z-10",children:"Contact Us"}),(0,a.jsx)(m.ArrowRight,{className:"w-5 h-5 relative z-10 transition-transform duration-300 group-hover:translate-x-1"})]})]})]})]})}],95415)}]);