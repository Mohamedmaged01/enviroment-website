module.exports=[54826,(a,b,c)=>{},15299,(a,b,c)=>{a.r(54826);var d=a.r(72131),e=d&&"object"==typeof d&&"default"in d?d:{default:d},f="undefined"!=typeof process&&process.env&&!0,g=function(a){return"[object String]"===Object.prototype.toString.call(a)},h=function(){function a(a){var b=void 0===a?{}:a,c=b.name,d=void 0===c?"stylesheet":c,e=b.optimizeForSpeed,h=void 0===e?f:e;i(g(d),"`name` must be a string"),this._name=d,this._deletedRulePlaceholder="#"+d+"-deleted-rule____{}",i("boolean"==typeof h,"`optimizeForSpeed` must be a boolean"),this._optimizeForSpeed=h,this._serverSheet=void 0,this._tags=[],this._injected=!1,this._rulesCount=0,this._nonce=null}var b,c=a.prototype;return c.setOptimizeForSpeed=function(a){i("boolean"==typeof a,"`setOptimizeForSpeed` accepts a boolean"),i(0===this._rulesCount,"optimizeForSpeed cannot be when rules have already been inserted"),this.flush(),this._optimizeForSpeed=a,this.inject()},c.isOptimizeForSpeed=function(){return this._optimizeForSpeed},c.inject=function(){var a=this;i(!this._injected,"sheet already injected"),this._injected=!0,this._serverSheet={cssRules:[],insertRule:function(b,c){return"number"==typeof c?a._serverSheet.cssRules[c]={cssText:b}:a._serverSheet.cssRules.push({cssText:b}),c},deleteRule:function(b){a._serverSheet.cssRules[b]=null}}},c.getSheetForTag=function(a){if(a.sheet)return a.sheet;for(var b=0;b<document.styleSheets.length;b++)if(document.styleSheets[b].ownerNode===a)return document.styleSheets[b]},c.getSheet=function(){return this.getSheetForTag(this._tags[this._tags.length-1])},c.insertRule=function(a,b){return i(g(a),"`insertRule` accepts only strings"),"number"!=typeof b&&(b=this._serverSheet.cssRules.length),this._serverSheet.insertRule(a,b),this._rulesCount++},c.replaceRule=function(a,b){this._optimizeForSpeed;var c=this._serverSheet;if(b.trim()||(b=this._deletedRulePlaceholder),!c.cssRules[a])return a;c.deleteRule(a);try{c.insertRule(b,a)}catch(d){f||console.warn("StyleSheet: illegal rule: \n\n"+b+"\n\nSee https://stackoverflow.com/q/20007992 for more info"),c.insertRule(this._deletedRulePlaceholder,a)}return a},c.deleteRule=function(a){this._serverSheet.deleteRule(a)},c.flush=function(){this._injected=!1,this._rulesCount=0,this._serverSheet.cssRules=[]},c.cssRules=function(){return this._serverSheet.cssRules},c.makeStyleTag=function(a,b,c){b&&i(g(b),"makeStyleTag accepts only strings as second parameter");var d=document.createElement("style");this._nonce&&d.setAttribute("nonce",this._nonce),d.type="text/css",d.setAttribute("data-"+a,""),b&&d.appendChild(document.createTextNode(b));var e=document.head||document.getElementsByTagName("head")[0];return c?e.insertBefore(d,c):e.appendChild(d),d},b=[{key:"length",get:function(){return this._rulesCount}}],function(a,b){for(var c=0;c<b.length;c++){var d=b[c];d.enumerable=d.enumerable||!1,d.configurable=!0,"value"in d&&(d.writable=!0),Object.defineProperty(a,d.key,d)}}(a.prototype,b),a}();function i(a,b){if(!a)throw Error("StyleSheet: "+b+".")}var j=function(a){for(var b=5381,c=a.length;c;)b=33*b^a.charCodeAt(--c);return b>>>0},k={};function l(a,b){if(!b)return"jsx-"+a;var c=String(b),d=a+c;return k[d]||(k[d]="jsx-"+j(a+"-"+c)),k[d]}function m(a,b){var c=a+(b=b.replace(/\/style/gi,"\\/style"));return k[c]||(k[c]=b.replace(/__jsx-style-dynamic-selector/g,a)),k[c]}var n=function(){function a(a){var b=void 0===a?{}:a,c=b.styleSheet,d=void 0===c?null:c,e=b.optimizeForSpeed,f=void 0!==e&&e;this._sheet=d||new h({name:"styled-jsx",optimizeForSpeed:f}),this._sheet.inject(),d&&"boolean"==typeof f&&(this._sheet.setOptimizeForSpeed(f),this._optimizeForSpeed=this._sheet.isOptimizeForSpeed()),this._fromServer=void 0,this._indices={},this._instancesCounts={}}var b=a.prototype;return b.add=function(a){var b=this;void 0===this._optimizeForSpeed&&(this._optimizeForSpeed=Array.isArray(a.children),this._sheet.setOptimizeForSpeed(this._optimizeForSpeed),this._optimizeForSpeed=this._sheet.isOptimizeForSpeed());var c=this.getIdAndRules(a),d=c.styleId,e=c.rules;if(d in this._instancesCounts){this._instancesCounts[d]+=1;return}var f=e.map(function(a){return b._sheet.insertRule(a)}).filter(function(a){return -1!==a});this._indices[d]=f,this._instancesCounts[d]=1},b.remove=function(a){var b=this,c=this.getIdAndRules(a).styleId;if(function(a,b){if(!a)throw Error("StyleSheetRegistry: "+b+".")}(c in this._instancesCounts,"styleId: `"+c+"` not found"),this._instancesCounts[c]-=1,this._instancesCounts[c]<1){var d=this._fromServer&&this._fromServer[c];d?(d.parentNode.removeChild(d),delete this._fromServer[c]):(this._indices[c].forEach(function(a){return b._sheet.deleteRule(a)}),delete this._indices[c]),delete this._instancesCounts[c]}},b.update=function(a,b){this.add(b),this.remove(a)},b.flush=function(){this._sheet.flush(),this._sheet.inject(),this._fromServer=void 0,this._indices={},this._instancesCounts={}},b.cssRules=function(){var a=this,b=this._fromServer?Object.keys(this._fromServer).map(function(b){return[b,a._fromServer[b]]}):[],c=this._sheet.cssRules();return b.concat(Object.keys(this._indices).map(function(b){return[b,a._indices[b].map(function(a){return c[a].cssText}).join(a._optimizeForSpeed?"":"\n")]}).filter(function(a){return!!a[1]}))},b.styles=function(a){var b,c;return b=this.cssRules(),void 0===(c=a)&&(c={}),b.map(function(a){var b=a[0],d=a[1];return e.default.createElement("style",{id:"__"+b,key:"__"+b,nonce:c.nonce?c.nonce:void 0,dangerouslySetInnerHTML:{__html:d}})})},b.getIdAndRules=function(a){var b=a.children,c=a.dynamic,d=a.id;if(c){var e=l(d,c);return{styleId:e,rules:Array.isArray(b)?b.map(function(a){return m(e,a)}):[m(e,b)]}}return{styleId:l(d),rules:Array.isArray(b)?b:[b]}},b.selectFromServer=function(){return Array.prototype.slice.call(document.querySelectorAll('[id^="__jsx-"]')).reduce(function(a,b){return a[b.id.slice(2)]=b,a},{})},a}(),o=d.createContext(null);function p(){return new n}function q(){return d.useContext(o)}function r(a){var b=q();return b&&b.add(a),null}o.displayName="StyleSheetContext",e.default.useInsertionEffect||e.default.useLayoutEffect,r.dynamic=function(a){return a.map(function(a){return l(a[0],a[1])}).join(" ")},c.StyleRegistry=function(a){var b=a.registry,c=a.children,f=d.useContext(o),g=d.useState(function(){return f||b||p()})[0];return e.default.createElement(o.Provider,{value:g},c)},c.createStyleRegistry=p,c.style=r,c.useStyleRegistry=q},31626,(a,b,c)=>{b.exports=a.r(15299).style},70106,a=>{"use strict";var b=a.i(72131);let c=a=>{let b=a.replace(/^([A-Z])|[\s-_]+(\w)/g,(a,b,c)=>c?c.toUpperCase():b.toLowerCase());return b.charAt(0).toUpperCase()+b.slice(1)},d=(...a)=>a.filter((a,b,c)=>!!a&&""!==a.trim()&&c.indexOf(a)===b).join(" ").trim();var e={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};let f=(0,b.forwardRef)(({color:a="currentColor",size:c=24,strokeWidth:f=2,absoluteStrokeWidth:g,className:h="",children:i,iconNode:j,...k},l)=>(0,b.createElement)("svg",{ref:l,...e,width:c,height:c,stroke:a,strokeWidth:g?24*Number(f)/Number(c):f,className:d("lucide",h),...!i&&!(a=>{for(let b in a)if(b.startsWith("aria-")||"role"===b||"title"===b)return!0})(k)&&{"aria-hidden":"true"},...k},[...j.map(([a,c])=>(0,b.createElement)(a,c)),...Array.isArray(i)?i:[i]])),g=(a,e)=>{let g=(0,b.forwardRef)(({className:g,...h},i)=>(0,b.createElement)(f,{ref:i,iconNode:e,className:d(`lucide-${c(a).replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase()}`,`lucide-${a}`,g),...h}));return g.displayName=c(a),g};a.s(["default",()=>g],70106)},13749,50522,a=>{"use strict";var b=a.i(70106);let c=(0,b.default)("chevron-left",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);a.s(["ChevronLeft",()=>c],13749);let d=(0,b.default)("chevron-right",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);a.s(["ChevronRight",()=>d],50522)},14528,a=>{"use strict";var b=a.i(87924),c=a.i(31626),d=a.i(72131),e=a.i(13749),f=a.i(50522);let g=(0,a.i(70106).default)("search",[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]]);function h(){let[a,h]=(0,d.useState)(0),[i,j]=(0,d.useState)(!1),[k,l]=(0,d.useState)(!1);(0,d.useEffect)(()=>{l(!0)},[]);let m=[{image:"https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&w=1920&q=80",title:"Recycle for a Better Tomorrow",description:"Join us in making the world greener by recycling waste responsibly."},{image:"https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=1920&q=80",title:"Sustainable Solutions",description:"We provide sustainable waste management solutions for businesses."},{image:"https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=1920&q=80",title:"Protect the Environment",description:"Our mission is to minimize environmental impact through recycling."}];(0,d.useEffect)(()=>{let a=setInterval(()=>{n()},5e3);return()=>clearInterval(a)},[a]);let n=()=>{i||(j(!0),h(a=>a===m.length-1?0:a+1),setTimeout(()=>j(!1),500))};return(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 min-h-screen bg-gray-100",children:[(0,b.jsx)(c.default,{id:"ab7aac2c1ae004f3",children:"@keyframes fadeInUp{0%{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}@keyframes fadeInDown{0%{opacity:0;transform:translateY(-30px)}to{opacity:1;transform:translateY(0)}}@keyframes slideInLeft{0%{opacity:0;transform:translate(-50px)}to{opacity:1;transform:translate(0)}}@keyframes slideInRight{0%{opacity:0;transform:translate(50px)}to{opacity:1;transform:translate(0)}}@keyframes pulse{0%,to{transform:scale(1)}50%{transform:scale(1.05)}}@keyframes float{0%,to{transform:translateY(0)}50%{transform:translateY(-10px)}}@keyframes shimmer{0%{background-position:-1000px 0}to{background-position:1000px 0}}.animate-fade-in-up.jsx-ab7aac2c1ae004f3{animation:.8s ease-out forwards fadeInUp}.animate-fade-in-down.jsx-ab7aac2c1ae004f3{animation:.8s ease-out forwards fadeInDown}.animate-slide-in-left.jsx-ab7aac2c1ae004f3{animation:.8s ease-out forwards slideInLeft}.animate-slide-in-right.jsx-ab7aac2c1ae004f3{animation:.8s ease-out forwards slideInRight}.animate-float.jsx-ab7aac2c1ae004f3{animation:3s ease-in-out infinite float}.animate-pulse-slow.jsx-ab7aac2c1ae004f3{animation:2s ease-in-out infinite pulse}.hover-lift.jsx-ab7aac2c1ae004f3{transition:all .3s}.hover-lift.jsx-ab7aac2c1ae004f3:hover{transform:translateY(-8px);box-shadow:0 20px 40px #00000026}.gradient-overlay.jsx-ab7aac2c1ae004f3{background:linear-gradient(135deg,#14b8a6e6 0%,#0d9488cc 100%)}.glass-effect.jsx-ab7aac2c1ae004f3{-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);background:#fffffff2;border:1px solid #fff3}.text-gradient.jsx-ab7aac2c1ae004f3{-webkit-text-fill-color:transparent;background:linear-gradient(135deg,#14b8a6 0%,#0d9488 100%);-webkit-background-clip:text;background-clip:text}.shimmer-effect.jsx-ab7aac2c1ae004f3{background:linear-gradient(90deg,#0000,#fff6,#0000) 0 0/200% 100%;animation:2s infinite shimmer}.card-hover.jsx-ab7aac2c1ae004f3{transition:all .4s cubic-bezier(.4,0,.2,1)}.card-hover.jsx-ab7aac2c1ae004f3:hover{transform:translateY(-12px)scale(1.02);box-shadow:0 25px 50px #0003}.icon-bounce.jsx-ab7aac2c1ae004f3:hover{animation:.6s ease-in-out pulse}.stagger-1.jsx-ab7aac2c1ae004f3{animation-delay:.1s}.stagger-2.jsx-ab7aac2c1ae004f3{animation-delay:.2s}.stagger-3.jsx-ab7aac2c1ae004f3{animation-delay:.3s}.stagger-4.jsx-ab7aac2c1ae004f3{animation-delay:.4s}.stagger-5.jsx-ab7aac2c1ae004f3{animation-delay:.5s}.stagger-6.jsx-ab7aac2c1ae004f3{animation-delay:.6s}"}),(0,b.jsx)("nav",{className:"jsx-ab7aac2c1ae004f3 bg-white shadow-lg relative z-50 animate-fade-in-down",children:(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 flex justify-between items-center h-20",children:[(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 flex items-center space-x-2",children:(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 w-32 h-16 flex items-center justify-center",children:(0,b.jsx)("img",{src:"/logo-en.png",alt:"REC Logo",className:"jsx-ab7aac2c1ae004f3 h-12 w-auto object-contain"})})}),(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 hidden md:flex items-center space-x-8",children:[(0,b.jsxs)("a",{href:"#",className:"jsx-ab7aac2c1ae004f3 text-green-600 font-medium relative group",children:["HOME",(0,b.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-0 left-0 w-full h-0.5 bg-green-600 transform origin-left"})]}),(0,b.jsxs)("a",{href:"#",className:"jsx-ab7aac2c1ae004f3 text-gray-600 hover:text-green-600 transition-all duration-300 relative group",children:["ABOUT",(0,b.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-0 left-0 w-0 h-0.5 bg-green-600 group-hover:w-full transition-all duration-300"})]}),(0,b.jsxs)("a",{href:"#",className:"jsx-ab7aac2c1ae004f3 text-gray-600 hover:text-green-600 transition-all duration-300 relative group",children:["SERVICES",(0,b.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-0 left-0 w-0 h-0.5 bg-green-600 group-hover:w-full transition-all duration-300"})]}),(0,b.jsxs)("a",{href:"#",className:"jsx-ab7aac2c1ae004f3 text-gray-600 hover:text-green-600 transition-all duration-300 relative group",children:["ELEMENTS",(0,b.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-0 left-0 w-0 h-0.5 bg-green-600 group-hover:w-full transition-all duration-300"})]}),(0,b.jsxs)("a",{href:"#",className:"jsx-ab7aac2c1ae004f3 text-gray-600 hover:text-green-600 transition-all duration-300 relative group",children:["BLOG",(0,b.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-0 left-0 w-0 h-0.5 bg-green-600 group-hover:w-full transition-all duration-300"})]}),(0,b.jsxs)("a",{href:"#",className:"jsx-ab7aac2c1ae004f3 text-gray-600 hover:text-green-600 transition-all duration-300 relative group",children:["CONTACT",(0,b.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-0 left-0 w-0 h-0.5 bg-green-600 group-hover:w-full transition-all duration-300"})]}),(0,b.jsx)("button",{className:"jsx-ab7aac2c1ae004f3 bg-green-500 hover:bg-green-600 text-white px-3 py-2 rounded font-medium transition-all duration-300 transform hover:scale-105 hover:shadow-lg relative overflow-hidden group flex items-center justify-center",children:(0,b.jsx)(g,{className:"w-6 h-6"})})]})]})})}),(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 relative h-[700px] overflow-hidden",children:[(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 absolute inset-0",children:m.map((c,d)=>(0,b.jsxs)("div",{className:`jsx-ab7aac2c1ae004f3 absolute inset-0 transition-all duration-700 ease-in-out ${d===a?"opacity-100 scale-100":"opacity-0 scale-105"}`,children:[(0,b.jsx)("img",{src:c.image,alt:c.title,style:{transform:d===a?"scale(1)":"scale(1.1)"},className:"jsx-ab7aac2c1ae004f3 w-full h-full object-cover transform transition-transform duration-700"}),(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 absolute inset-0 bg-gradient-to-r from-black/50 to-black/30"}),(0,b.jsxs)("div",{className:`jsx-ab7aac2c1ae004f3 absolute left-8 sm:left-16 top-1/3 glass-effect rounded-xl p-8 shadow-2xl max-w-md transform transition-all duration-700 delay-300 ${d===a?"translate-x-0 opacity-100":"-translate-x-20 opacity-0"}`,children:[(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 w-16 h-1 bg-linear-to-r from-green-600 to-teal-500 mb-4 rounded-full"}),(0,b.jsx)("h2",{className:"jsx-ab7aac2c1ae004f3 text-4xl font-bold text-gray-800 mb-4 leading-tight",children:(0,b.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 text-gradient",children:c.title})}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-700 text-lg leading-relaxed mb-6",children:c.description}),(0,b.jsxs)("button",{className:"jsx-ab7aac2c1ae004f3 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-xl relative overflow-hidden group",children:[(0,b.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 relative z-10",children:"LEARN MORE"}),(0,b.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 absolute inset-0 bg-white/20 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300"})]})]})]},d))}),(0,b.jsx)("button",{onClick:()=>{i||(j(!0),h(a=>0===a?m.length-1:a-1),setTimeout(()=>j(!1),500))},disabled:i,className:"jsx-ab7aac2c1ae004f3 absolute left-4 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/90 hover:bg-white backdrop-blur-sm rounded-full flex items-center justify-center z-30 transition-all duration-300 hover:scale-110 hover:shadow-xl disabled:opacity-50 group",children:(0,b.jsx)(e.ChevronLeft,{className:"w-7 h-7 text-gray-700 group-hover:text-green-600 transition-colors"})}),(0,b.jsx)("button",{onClick:n,disabled:i,className:"jsx-ab7aac2c1ae004f3 absolute right-4 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/90 hover:bg-white backdrop-blur-sm rounded-full flex items-center justify-center z-30 transition-all duration-300 hover:scale-110 hover:shadow-xl disabled:opacity-50 group",children:(0,b.jsx)(f.ChevronRight,{className:"w-7 h-7 text-gray-700 group-hover:text-green-600 transition-colors"})}),(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-3 z-30",children:m.map((c,d)=>(0,b.jsx)("button",{onClick:()=>{i||(j(!0),h(d),setTimeout(()=>j(!1),500))},className:`jsx-ab7aac2c1ae004f3 h-2 rounded-full transition-all ${d===a?"w-12 bg-white":"w-2 bg-white/50 hover:bg-white/75"}`},d))})]}),(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 relative -mt-32 z-20",children:(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 grid grid-cols-1 md:grid-cols-3 gap-6 shadow-2xl",children:[(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 bg-linear-to-br from-teal-500 to-teal-600 text-white p-8 hover:from-teal-600 hover:to-teal-700 transition-all duration-300 rounded-xl transform hover:-translate-y-2 hover:shadow-2xl cursor-pointer",children:[(0,b.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold mb-2",children:"INDUSTRIAL"}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 italic text-lg mb-4 opacity-90",children:"Waste Management"}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-sm leading-relaxed opacity-90",children:"We offer complete industrial waste management services, from collection to recycling."})]}),(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 bg-white p-8 hover:bg-gray-50 transition-all duration-300 rounded-xl transform hover:-translate-y-2 hover:shadow-2xl cursor-pointer border-2 border-transparent hover:border-teal-500",children:[(0,b.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-teal-600 mb-2",children:"SUSTAINABLE"}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 italic text-lg text-gray-600 mb-4",children:"Business Solutions"}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-sm text-gray-700 leading-relaxed",children:"We help business adopt sustainable and environmentally responsible recycling practices."})]}),(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 bg-white p-8 hover:bg-gray-50 transition-all duration-300 rounded-xl transform hover:-translate-y-2 hover:shadow-2xl cursor-pointer border-2 border-transparent hover:border-teal-500",children:[(0,b.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-teal-600 mb-2",children:"ENVIRONMENTAL"}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 italic text-lg text-gray-600 mb-4",children:"Quality Services"}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-sm text-gray-700 leading-relaxed",children:"We focus on disposing of all waste sustainably and minimizing environmental impact."})]})]})})}),(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 py-20 bg-linear-to-b from-gray-50 to-white",children:(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center",children:[(0,b.jsxs)("div",{className:`jsx-ab7aac2c1ae004f3 ${k?"animate-slide-in-left":"opacity-0"}`,children:[(0,b.jsxs)("h2",{className:"jsx-ab7aac2c1ae004f3 text-4xl font-bold text-gray-800 mb-4",children:["Welcome to ",(0,b.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 text-gradient",children:"Recycle"})]}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-lg text-gray-600 mb-6 font-medium",children:"We are a Leading Global Waste Management Company, Committed to The Environment"}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 mb-8 leading-relaxed",children:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam massa ligula, aliquet euismod eleifend vitae, interdum ut mi. Praesent fringilla pharetra sapien sit amet semper. Nunc id massa ut mi tempus mattis ac eu lectus."}),(0,b.jsx)("button",{className:"jsx-ab7aac2c1ae004f3 border-2 border-teal-600 text-teal-600 px-8 py-3 rounded-lg hover:bg-teal-600 hover:text-white transition-all duration-300 font-semibold transform hover:scale-105 hover:shadow-lg",children:"OUR SERVICES"})]}),(0,b.jsxs)("div",{className:`jsx-ab7aac2c1ae004f3 relative group ${k?"animate-slide-in-right":"opacity-0"}`,children:[(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 absolute inset-0 bg-linear-to-r from-teal-400 to-green-500 rounded-xl transform rotate-3 group-hover:rotate-6 transition-transform duration-300"}),(0,b.jsx)("img",{src:m[0].image,alt:m[0].title,className:"jsx-ab7aac2c1ae004f3 relative w-full rounded-xl shadow-2xl transform -rotate-1 group-hover:rotate-0 transition-transform duration-300"}),(0,b.jsx)("button",{className:"jsx-ab7aac2c1ae004f3 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-all duration-300 group-hover:bg-teal-500 animate-pulse-slow",children:(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 w-0 h-0 border-t-8 border-t-transparent border-l-12 border-l-teal-600 border-b-8 border-b-transparent ml-1 group-hover:border-l-white transition-colors"})})]})]})})}),(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 py-20 bg-white relative overflow-hidden",children:[(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 absolute top-0 right-0 w-96 h-96 bg-teal-100 rounded-full filter blur-3xl opacity-20 -z-10"}),(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 absolute bottom-0 left-0 w-96 h-96 bg-green-100 rounded-full filter blur-3xl opacity-20 -z-10"}),(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:[(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 text-center mb-16",children:[(0,b.jsxs)("h2",{className:"jsx-ab7aac2c1ae004f3 text-4xl font-bold text-gray-800 mb-4",children:["Services & ",(0,b.jsx)("span",{className:"jsx-ab7aac2c1ae004f3 text-gradient",children:"Solutions"})]}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 italic max-w-4xl mx-auto text-lg",children:"We offer comprehensive recycling, industry-specific waste management, quality control & sustainability solutions for businesses and corporations."})]}),(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 grid grid-cols-1 md:grid-cols-3 gap-12",children:[(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 text-center group card-hover",children:[(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 inline-flex items-center justify-center w-24 h-24 mb-6 bg-gradient-to-br from-teal-100 to-green-100 rounded-2xl",children:(0,b.jsxs)("svg",{viewBox:"0 0 64 64",fill:"none",stroke:"currentColor",strokeWidth:"2",className:"jsx-ab7aac2c1ae004f3 w-12 h-12 text-teal-600",children:[(0,b.jsx)("path",{d:"M20 16 L28 8 L36 16 M32 12 L32 32",className:"jsx-ab7aac2c1ae004f3"}),(0,b.jsx)("rect",{x:"12",y:"28",width:"40",height:"28",rx:"2",className:"jsx-ab7aac2c1ae004f3"}),(0,b.jsx)("circle",{cx:"32",cy:"42",r:"6",className:"jsx-ab7aac2c1ae004f3"})]})}),(0,b.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-gray-800 mb-3 group-hover:text-teal-600 transition-colors",children:"Waste Collection"}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 text-sm leading-relaxed",children:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."})]}),(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 text-center group card-hover",children:[(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 inline-flex items-center justify-center w-24 h-24 mb-6 bg-gradient-to-br from-teal-100 to-green-100 rounded-2xl",children:(0,b.jsxs)("svg",{viewBox:"0 0 64 64",fill:"none",stroke:"currentColor",strokeWidth:"2",className:"jsx-ab7aac2c1ae004f3 w-12 h-12 text-teal-600",children:[(0,b.jsx)("path",{d:"M32 12 L42 22 L38 22 L38 32 L26 32 L26 22 L22 22 Z",className:"jsx-ab7aac2c1ae004f3"}),(0,b.jsx)("path",{d:"M16 38 L26 28 L26 32 L36 32 L36 42 L26 42 L26 38 Z",className:"jsx-ab7aac2c1ae004f3"}),(0,b.jsx)("path",{d:"M48 38 L48 42 L38 42 L38 32 L48 32 L48 36 L42 28 Z",className:"jsx-ab7aac2c1ae004f3"})]})}),(0,b.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-gray-800 mb-3 group-hover:text-teal-600 transition-colors",children:"Recycling Services"}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 text-sm leading-relaxed",children:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."})]}),(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 text-center group card-hover",children:[(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 inline-flex items-center justify-center w-24 h-24 mb-6 bg-gradient-to-br from-teal-100 to-green-100 rounded-2xl",children:(0,b.jsxs)("svg",{viewBox:"0 0 64 64",fill:"none",stroke:"currentColor",strokeWidth:"2",className:"jsx-ab7aac2c1ae004f3 w-12 h-12 text-teal-600",children:[(0,b.jsx)("path",{d:"M32 8 Q40 16 40 28 Q40 40 32 48 Q24 40 24 28 Q24 16 32 8 Z",className:"jsx-ab7aac2c1ae004f3"}),(0,b.jsx)("circle",{cx:"32",cy:"28",r:"4",className:"jsx-ab7aac2c1ae004f3"}),(0,b.jsx)("path",{d:"M28 36 L32 40 L36 36",className:"jsx-ab7aac2c1ae004f3"})]})}),(0,b.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-gray-800 mb-3 group-hover:text-teal-600 transition-colors",children:"Environmental"}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 text-sm leading-relaxed",children:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."})]}),(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 text-center group card-hover",children:[(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 inline-flex items-center justify-center w-24 h-24 mb-6 bg-gradient-to-br from-teal-100 to-green-100 rounded-2xl",children:(0,b.jsxs)("svg",{viewBox:"0 0 64 64",fill:"none",stroke:"currentColor",strokeWidth:"2",className:"jsx-ab7aac2c1ae004f3 w-12 h-12 text-teal-600",children:[(0,b.jsx)("circle",{cx:"32",cy:"32",r:"20",className:"jsx-ab7aac2c1ae004f3"}),(0,b.jsx)("path",{d:"M24 32 L30 38 L42 26",strokeWidth:"3",className:"jsx-ab7aac2c1ae004f3"})]})}),(0,b.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-gray-800 mb-3 group-hover:text-teal-600 transition-colors",children:"Quality Audits"}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 text-sm leading-relaxed",children:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."})]}),(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 text-center group card-hover",children:[(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 inline-flex items-center justify-center w-24 h-24 mb-6 bg-gradient-to-br from-teal-100 to-green-100 rounded-2xl",children:(0,b.jsxs)("svg",{viewBox:"0 0 64 64",fill:"none",stroke:"currentColor",strokeWidth:"2",className:"jsx-ab7aac2c1ae004f3 w-12 h-12 text-teal-600",children:[(0,b.jsx)("path",{d:"M32 48 Q28 44 28 38 Q28 32 32 28 Q36 32 36 38 Q36 44 32 48 Z",className:"jsx-ab7aac2c1ae004f3"}),(0,b.jsx)("path",{d:"M26 38 Q22 34 22 28 Q22 22 26 18",className:"jsx-ab7aac2c1ae004f3"}),(0,b.jsx)("path",{d:"M38 38 Q42 34 42 28 Q42 22 38 18",className:"jsx-ab7aac2c1ae004f3"})]})}),(0,b.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-gray-800 mb-3 group-hover:text-teal-600 transition-colors",children:"BIO Fuel Production"}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 text-sm leading-relaxed",children:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."})]}),(0,b.jsxs)("div",{className:"jsx-ab7aac2c1ae004f3 text-center group card-hover",children:[(0,b.jsx)("div",{className:"jsx-ab7aac2c1ae004f3 inline-flex items-center justify-center w-24 h-24 mb-6 bg-gradient-to-br from-teal-100 to-green-100 rounded-2xl",children:(0,b.jsxs)("svg",{viewBox:"0 0 64 64",fill:"none",stroke:"currentColor",strokeWidth:"2",className:"jsx-ab7aac2c1ae004f3 w-12 h-12 text-teal-600",children:[(0,b.jsx)("path",{d:"M32 12 Q36 16 36 22 L36 32",className:"jsx-ab7aac2c1ae004f3"}),(0,b.jsx)("path",{d:"M24 20 Q28 16 32 16 Q36 16 40 20",className:"jsx-ab7aac2c1ae004f3"}),(0,b.jsx)("circle",{cx:"32",cy:"38",r:"8",className:"jsx-ab7aac2c1ae004f3"}),(0,b.jsx)("path",{d:"M28 46 L28 52 M36 46 L36 52",className:"jsx-ab7aac2c1ae004f3"})]})}),(0,b.jsx)("h3",{className:"jsx-ab7aac2c1ae004f3 text-xl font-bold text-gray-800 mb-3 group-hover:text-teal-600 transition-colors",children:"Sustainability"}),(0,b.jsx)("p",{className:"jsx-ab7aac2c1ae004f3 text-gray-600 text-sm leading-relaxed",children:"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore."})]})]})]})]})]})}a.s(["default",()=>h],14528)},32860,a=>{"use strict";let b=(0,a.i(70106).default)("arrow-right",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]);a.s(["ArrowRight",()=>b],32860)},91930,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(13749),e=a.i(50522),f=a.i(70106);let g=(0,f.default)("clock",[["path",{d:"M12 6v6l4 2",key:"mmk7yg"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]),h=(0,f.default)("tag",[["path",{d:"M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z",key:"vktsd0"}],["circle",{cx:"7.5",cy:"7.5",r:".5",fill:"currentColor",key:"kqv944"}]]);var i=a.i(32860);function j(){let[a,f]=c.default.useState(null),[j,k]=c.default.useState(0),l=[{date:"11/2025",category:"POST | FORMATS | RECYCLING",title:"Recycling basics",description:"Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi gravida fringilla neque sit amet sollicitudin. Duis aliquam dictum feugiat. Quisque...",readTime:"5 min read"},{date:"11/2025",category:"RECYCLING",title:"Waste Collection Today",description:"Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi gravida fringilla neque sit amet sollicitudin. Duis aliquam dictum feugiat. Quisque...",readTime:"3 min read"},{date:"11/2025",category:"RECYCLING",title:"How to Recycle Paper",description:"Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi gravida fringilla neque sit amet sollicitudin. Duis aliquam dictum feugiat. Quisque...",readTime:"4 min read"}];return(0,b.jsxs)("div",{className:"relative bg-gradient-to-br from-emerald-400 via-teal-500 to-green-500 min-h-screen overflow-hidden",children:[(0,b.jsx)("style",{children:`
        @keyframes float {
          0%, 100% { transform: translate(0, 0) scale(1); }
          33% { transform: translate(30px, -30px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
        }
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes shimmer {
          0% { background-position: -1000px 0; }
          100% { background-position: 1000px 0; }
        }
        @keyframes wave {
          0%, 100% { d: path("M0,40 Q120,0 240,40 T480,40 T720,40 T960,40 T1200,40 T1440,40 L1440,80 L0,80 Z"); }
          50% { d: path("M0,40 Q120,60 240,40 T480,40 T720,40 T960,40 T1200,40 T1440,40 L1440,80 L0,80 Z"); }
        }
        @keyframes fadeInScale {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        @keyframes glowPulse {
          0%, 100% { box-shadow: 0 0 20px rgba(16, 185, 129, 0.4), 0 0 40px rgba(16, 185, 129, 0.2); }
          50% { box-shadow: 0 0 30px rgba(16, 185, 129, 0.6), 0 0 60px rgba(16, 185, 129, 0.3); }
        }
        @keyframes borderGlow {
          0%, 100% { border-color: rgba(16, 185, 129, 0.5); }
          50% { border-color: rgba(16, 185, 129, 1); }
        }
        @keyframes gradientShift {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        @keyframes ripple {
          0% { transform: scale(0); opacity: 1; }
          100% { transform: scale(4); opacity: 0; }
        }
        @keyframes slideInLeft {
          from { opacity: 0; transform: translateX(-50px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes slideInRight {
          from { opacity: 0; transform: translateX(50px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        @keyframes rotate {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        
        .animate-float { animation: float 20s ease-in-out infinite; }
        .animate-float-delayed { animation: float 25s ease-in-out infinite 5s; }
        .animate-float-slow { animation: float 30s ease-in-out infinite 10s; }
        .animate-slide-up { animation: slideUp 0.6s ease-out forwards; opacity: 0; }
        .animate-slide-in-left { animation: slideInLeft 0.8s ease-out forwards; }
        .animate-slide-in-right { animation: slideInRight 0.8s ease-out forwards; }
        .anim-delay-100 { animation-delay: 0.1s; }
        .anim-delay-200 { animation-delay: 0.2s; }
        .anim-delay-300 { animation-delay: 0.3s; }
        .anim-delay-400 { animation-delay: 0.4s; }
        
        .shimmer-btn {
          background: linear-gradient(90deg, #a3e635 0%, #bef264 50%, #a3e635 100%);
          background-size: 200% 100%;
          animation: shimmer 3s linear infinite;
        }
        
        .card-hover {
          transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
          position: relative;
          overflow: hidden;
        }
        
        .card-hover::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
          transition: left 0.5s;
        }
        
        .card-hover:hover::before {
          left: 100%;
        }
        
        .card-hover::after {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(20, 184, 166, 0.1));
          opacity: 0;
          transition: opacity 0.4s;
        }
        
        .card-hover:hover::after {
          opacity: 1;
        }
        
        .card-hover:hover {
          transform: translateY(-16px) scale(1.03);
          box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.3), 0 0 0 4px rgba(16, 185, 129, 0.2);
        }
        
        .wave-animate path {
          animation: wave 8s ease-in-out infinite;
        }
        
        .date-badge {
          position: relative;
          display: inline-block;
          background: linear-gradient(135deg, #10b981, #14b8a6);
          background-size: 200% 200%;
          animation: gradientShift 3s ease infinite;
        }
        
        .category-badge {
          position: relative;
          overflow: hidden;
        }
        
        .category-badge::before {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          width: 0;
          height: 0;
          background: rgba(255, 255, 255, 0.3);
          border-radius: 50%;
          transform: translate(-50%, -50%);
          transition: width 0.6s, height 0.6s;
        }
        
        .card-hover:hover .category-badge::before {
          width: 200px;
          height: 200px;
        }
        
        .btn-arrow {
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          position: relative;
          overflow: hidden;
        }
        
        .btn-arrow::before {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          width: 0;
          height: 0;
          background: rgba(16, 185, 129, 0.2);
          border-radius: 50%;
          transform: translate(-50%, -50%);
          transition: width 0.4s, height 0.4s;
        }
        
        .btn-arrow:hover::before {
          width: 150px;
          height: 150px;
        }
        
        .btn-arrow:hover {
          transform: scale(1.15) rotate(5deg);
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
          background: rgba(255, 255, 255, 0.95);
        }
        
        .btn-arrow:active {
          transform: scale(0.95) rotate(-5deg);
        }
        
        .learn-more-btn {
          position: relative;
          overflow: hidden;
        }
        
        .learn-more-btn::before {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          width: 0;
          height: 0;
          background: rgba(255, 255, 255, 0.2);
          border-radius: 50%;
          transform: translate(-50%, -50%);
          transition: width 0.6s, height 0.6s;
        }
        
        .learn-more-btn:hover::before {
          width: 300px;
          height: 300px;
        }
        
        .title-gradient {
          background: linear-gradient(135deg, #ffffff, #f0fdf4);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: gradientShift 4s ease infinite;
          background-size: 200% 200%;
        }
        
        .glow-text {
          text-shadow: 0 0 20px rgba(255, 255, 255, 0.5), 0 0 40px rgba(255, 255, 255, 0.3);
        }
        
        .card-corner {
          position: absolute;
          width: 0;
          height: 0;
          border-style: solid;
          transition: all 0.4s;
        }
        
        .card-corner-tl {
          top: 0;
          left: 0;
          border-width: 0 0 0 0;
          border-color: transparent transparent transparent #10b981;
        }
        
        .card-hover:hover .card-corner-tl {
          border-width: 40px 0 0 40px;
        }
        
        .card-corner-br {
          bottom: 0;
          right: 0;
          border-width: 0 0 0 0;
          border-color: transparent #10b981 transparent transparent;
        }
        
        .card-hover:hover .card-corner-br {
          border-width: 0 40px 40px 0;
        }
        
        .icon-float {
          animation: bounce 2s ease-in-out infinite;
        }
        
        .icon-rotate {
          transition: transform 0.4s;
        }
        
        .card-hover:hover .icon-rotate {
          transform: rotate(360deg);
        }
      `}),(0,b.jsxs)("div",{className:"absolute inset-0 overflow-hidden",children:[(0,b.jsx)("div",{className:"absolute top-20 left-10 w-96 h-96 bg-teal-600/20 rounded-full blur-3xl animate-float"}),(0,b.jsx)("div",{className:"absolute top-40 right-20 w-80 h-80 bg-emerald-600/20 rounded-full blur-3xl animate-float-delayed"}),(0,b.jsx)("div",{className:"absolute bottom-20 left-1/3 w-96 h-96 bg-green-600/20 rounded-full blur-3xl animate-float-slow"}),(0,b.jsx)("div",{className:"absolute top-1/4 right-1/4 w-64 h-64 bg-white/5 rounded-full blur-2xl animate-float"}),(0,b.jsx)("div",{className:"absolute bottom-1/4 left-1/4 w-72 h-72 bg-white/5 rounded-full blur-2xl animate-float-delayed"})]}),(0,b.jsxs)("div",{className:"relative container mx-auto px-4 py-16 pb-32",children:[(0,b.jsxs)("div",{className:"text-center mb-16 animate-slide-up",children:[(0,b.jsx)("h2",{className:"text-white text-5xl md:text-6xl font-bold mb-6 drop-shadow-2xl title-gradient glow-text",children:"Latest Articles"}),(0,b.jsxs)("div",{className:"flex items-center justify-center gap-2 mb-6",children:[(0,b.jsx)("div",{className:"h-1 w-20 bg-white/50 rounded-full animate-slide-in-left"}),(0,b.jsx)("div",{className:"h-2 w-2 bg-white rounded-full icon-float"}),(0,b.jsx)("div",{className:"h-1 w-20 bg-white/50 rounded-full animate-slide-in-right"})]}),(0,b.jsx)("p",{className:"text-white/95 text-lg max-w-4xl mx-auto italic leading-relaxed drop-shadow-lg animate-slide-up anim-delay-200",children:"Lorem ipsum dolor sit amet, consectetuer. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit."})]}),(0,b.jsx)("div",{className:"grid md:grid-cols-3 gap-8 max-w-7xl mx-auto mb-12",children:l.map((a,c)=>(0,b.jsxs)("div",{onMouseEnter:()=>f(c),onMouseLeave:()=>f(null),className:`bg-white p-8 rounded-lg shadow-2xl card-hover animate-slide-up ${1===c?"anim-delay-100":2===c?"anim-delay-200":""}`,children:[(0,b.jsx)("div",{className:"card-corner card-corner-tl"}),(0,b.jsx)("div",{className:"card-corner card-corner-br"}),(0,b.jsxs)("div",{className:"mb-6 relative z-10",children:[(0,b.jsxs)("div",{className:"flex items-center gap-3 mb-3",children:[(0,b.jsxs)("span",{className:"date-badge text-white text-xs font-bold uppercase px-3 py-1 rounded-full",children:[(0,b.jsx)(g,{className:"w-3 h-3 inline mr-1"}),a.date]}),(0,b.jsx)("span",{className:"text-gray-400 text-xs",children:a.readTime})]}),(0,b.jsxs)("div",{className:"category-badge inline-block bg-emerald-50 text-emerald-600 text-xs uppercase tracking-wide px-3 py-1 rounded-full font-semibold",children:[(0,b.jsx)(h,{className:"w-3 h-3 inline mr-1 icon-rotate"}),a.category]})]}),(0,b.jsx)("h3",{className:"text-gray-800 text-2xl font-bold mb-4 transition-all duration-300 hover:text-emerald-600 relative z-10 leading-tight",children:a.title}),(0,b.jsx)("p",{className:"text-gray-600 text-sm leading-relaxed mb-6 relative z-10",children:a.description}),(0,b.jsxs)("button",{className:"learn-more-btn bg-emerald-500 text-white px-6 py-3 rounded-full text-sm font-semibold uppercase hover:bg-emerald-600 transition-all duration-300 hover:shadow-xl hover:scale-105 active:scale-95 flex items-center gap-2 group relative z-10",children:["LEARN MORE",(0,b.jsx)(i.ArrowRight,{className:"w-4 h-4 transition-transform duration-300 group-hover:translate-x-2"})]})]},c))}),(0,b.jsxs)("div",{className:"flex justify-center gap-4 max-w-6xl mx-auto animate-slide-up anim-delay-300",children:[(0,b.jsx)("button",{onClick:()=>{k(a=>a>0?a-1:l.length-1)},className:"btn-arrow bg-white p-4 rounded-full hover:bg-gray-50 transition-all duration-300 shadow-lg relative z-10",children:(0,b.jsx)(d.ChevronLeft,{className:"w-6 h-6 text-gray-700"})}),(0,b.jsx)("button",{onClick:()=>{k(a=>a<l.length-1?a+1:0)},className:"btn-arrow bg-white p-4 rounded-full hover:bg-gray-50 transition-all duration-300 shadow-lg relative z-10",children:(0,b.jsx)(e.ChevronRight,{className:"w-6 h-6 text-gray-700"})})]}),(0,b.jsx)("div",{className:"flex justify-center gap-2 mt-8 animate-slide-up anim-delay-400",children:l.map((a,c)=>(0,b.jsx)("button",{onClick:()=>k(c),className:`h-2 rounded-full transition-all duration-300 ${j===c?"w-8 bg-white":"w-2 bg-white/50 hover:bg-white/75"}`},c))})]}),(0,b.jsx)("div",{className:"absolute bottom-0 left-0 right-0",children:(0,b.jsx)("svg",{className:"w-full h-20 wave-animate",viewBox:"0 0 1440 80",preserveAspectRatio:"none",children:(0,b.jsx)("path",{d:"M0,40 Q120,0 240,40 T480,40 T720,40 T960,40 T1200,40 T1440,40 L1440,80 L0,80 Z",fill:"white"})})})]})}a.s(["default",()=>j],91930)},73358,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(13749),e=a.i(50522),f=a.i(70106);let g=(0,f.default)("user",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]]),h=(0,f.default)("calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]]),i=(0,f.default)("message-circle",[["path",{d:"M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",key:"1sd12s"}]]),j=(0,f.default)("music",[["path",{d:"M9 18V5l12-2v13",key:"1jmyc2"}],["circle",{cx:"6",cy:"18",r:"3",key:"fqmcym"}],["circle",{cx:"18",cy:"16",r:"3",key:"1hluhg"}]]),k=(0,f.default)("play",[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",key:"10ikf1"}]]),l=({image:a,title:d,author:f,date:j,comments:k,description:l,icon:m})=>{let[n,o]=(0,c.useState)(!1);return(0,b.jsxs)("div",{className:"bg-white rounded-lg shadow-md overflow-hidden group transition-all duration-500 hover:shadow-2xl card-float",onMouseEnter:()=>o(!0),onMouseLeave:()=>o(!1),children:[(0,b.jsxs)("div",{className:"relative h-56 overflow-hidden",children:[(0,b.jsx)("img",{src:a,alt:d,className:"w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"}),(0,b.jsx)("div",{className:"absolute inset-0 bg-linear-to-t from-black/60 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"}),m&&(0,b.jsx)("div",{className:"absolute inset-0 flex items-center justify-center",children:(0,b.jsx)("div",{className:`bg-white rounded-full p-4 shadow-lg transition-all duration-500 ${n?"scale-110 rotate-12":"scale-100"}`,children:(0,b.jsx)(m,{className:"w-8 h-8 text-green-600 transition-colors duration-300 group-hover:text-green-500"})})})]}),(0,b.jsxs)("div",{className:"p-6",children:[(0,b.jsx)("h3",{className:"text-xl font-semibold text-gray-800 mb-4 transition-colors duration-300 group-hover:text-green-600",children:d}),(0,b.jsxs)("div",{className:"flex items-center gap-4 text-sm text-gray-600 mb-4",children:[(0,b.jsxs)("div",{className:"flex items-center gap-1 transition-transform duration-300 hover:scale-110",children:[(0,b.jsx)(g,{className:"w-4 h-4"}),(0,b.jsx)("span",{className:"text-green-600",children:f})]}),(0,b.jsxs)("div",{className:"flex items-center gap-1 transition-transform duration-300 hover:scale-110",children:[(0,b.jsx)(h,{className:"w-4 h-4"}),(0,b.jsx)("span",{children:j})]}),(0,b.jsxs)("div",{className:"flex items-center gap-1 transition-transform duration-300 hover:scale-110",children:[(0,b.jsx)(i,{className:"w-4 h-4"}),(0,b.jsx)("span",{children:k})]})]}),(0,b.jsx)("p",{className:"text-gray-600 leading-relaxed mb-4",children:l}),(0,b.jsxs)("button",{className:"text-green-600 font-medium flex items-center gap-2 transition-all duration-300 hover:gap-3 group/btn",children:["Continue",(0,b.jsx)(e.ChevronRight,{className:"w-4 h-4 transition-transform duration-300 group-hover/btn:translate-x-1"})]})]})]})};function m(){let[a,f]=(0,c.useState)(0),g=[{image:"https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=800&h=600&fit=crop",title:"Environment Perspective",author:"Johny Walker",date:"11/2025",comments:"0",description:"Mauris id enim id purus ornare tincidunt. Aenean vel consequat risus. Proin viverra nisi at nisl imperdiet auctor.",icon:null},{image:"https://images.unsplash.com/photo-1535083783855-76ae62b2914e?w=800&h=600&fit=crop",title:"New Ecological Bulbs",author:"Johny Walker",date:"11/2025",comments:"0",description:"Mauris id enim id purus ornare tincidunt. Aenean vel consequat risus. Proin viverra nisi at nisl imperdiet auctor.",icon:j},{image:"https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?w=800&h=600&fit=crop",title:"Protect The Environment",author:"Johny Walker",date:"11/2025",comments:"0",description:"Mauris id enim id purus ornare tincidunt. Aenean vel consequat risus. Proin viverra nisi at nisl imperdiet auctor.",icon:k}];return(0,b.jsxs)("div",{className:"bg-gray-50 py-16 px-4 relative overflow-hidden",children:[(0,b.jsx)("style",{children:`
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(40px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes cardFloat {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        @keyframes shimmerLine {
          0% { transform: scaleX(0); transform-origin: left; }
          50% { transform: scaleX(1); transform-origin: left; }
          51% { transform: scaleX(1); transform-origin: right; }
          100% { transform: scaleX(0); transform-origin: right; }
        }
        @keyframes pulse {
          0%, 100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(22, 163, 74, 0.4); }
          50% { transform: scale(1.05); box-shadow: 0 0 0 10px rgba(22, 163, 74, 0); }
        }
        @keyframes gradientMove {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        .card-float:hover { animation: cardFloat 2s ease-in-out infinite; }
        .title-animate { animation: fadeInUp 0.8s ease-out; }
        .underline-animate { animation: shimmerLine 2s ease-in-out infinite; }
        .nav-btn { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
        .nav-btn:not(:disabled):hover { animation: pulse 1s ease-in-out infinite; }
        .nav-btn:active { transform: scale(0.9); }
        .nav-btn:disabled { cursor: not-allowed; opacity: 0.3; }
        .bg-pattern { 
          background-image: 
            radial-gradient(circle at 20% 50%, rgba(22, 163, 74, 0.05) 0%, transparent 50%),
            radial-gradient(circle at 80% 80%, rgba(22, 163, 74, 0.05) 0%, transparent 50%);
        }
        .gradient-text {
          background: linear-gradient(135deg, #059669, #10b981, #34d399);
          background-size: 200% 200%;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: gradientMove 3s ease infinite;
        }
      `}),(0,b.jsx)("div",{className:"absolute inset-0 bg-pattern"}),(0,b.jsxs)("div",{className:"max-w-7xl mx-auto relative",children:[(0,b.jsxs)("div",{className:"flex items-center justify-between mb-12",children:[(0,b.jsx)("div",{className:"flex-1"}),(0,b.jsxs)("div",{className:"text-center title-animate",children:[(0,b.jsxs)("h2",{className:"text-4xl font-bold text-gray-800 mb-3",children:["LATEST ",(0,b.jsx)("span",{className:"gradient-text",children:"NEWS"})]}),(0,b.jsx)("div",{className:"relative h-1 w-16 mx-auto bg-gray-200 rounded-full overflow-hidden",children:(0,b.jsx)("div",{className:"absolute inset-0 bg-linear-to-r from-green-400 via-green-600 to-green-400 underline-animate"})})]}),(0,b.jsxs)("div",{className:"flex-1 flex justify-end gap-3",children:[(0,b.jsx)("button",{onClick:()=>f(Math.max(0,a-1)),className:"nav-btn bg-green-600 text-white p-3 rounded-full hover:bg-green-700 disabled:opacity-50 shadow-lg",disabled:0===a,children:(0,b.jsx)(d.ChevronLeft,{className:"w-5 h-5"})}),(0,b.jsx)("button",{onClick:()=>f(Math.min(g.length-3,a+1)),className:"nav-btn bg-green-600 text-white p-3 rounded-full hover:bg-green-700 disabled:opacity-50 shadow-lg",disabled:a>=g.length-3,children:(0,b.jsx)(e.ChevronRight,{className:"w-5 h-5"})})]})]}),(0,b.jsx)("div",{className:"overflow-hidden",children:(0,b.jsx)("div",{className:"flex transition-transform duration-700 ease-out",style:{transform:`translateX(-${33.333*a}%)`},children:g.map((a,c)=>(0,b.jsx)("div",{className:"w-1/3 shrink-0 px-3",style:{animation:`fadeInUp 0.6s ease-out ${.1*c}s both`},children:(0,b.jsx)(l,{...a})},c))})})]})]})}a.s(["default",()=>m],73358)},4582,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(70106);let e=(0,d.default)("leaf",[["path",{d:"M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z",key:"nnexq3"}],["path",{d:"M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12",key:"mt58a7"}]]),f=(0,d.default)("trending-up",[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]]),g=(0,d.default)("lightbulb",[["path",{d:"M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",key:"1gvzjb"}],["path",{d:"M9 18h6",key:"x1upvd"}],["path",{d:"M10 22h4",key:"ceow96"}]]),h=(0,d.default)("briefcase",[["path",{d:"M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16",key:"jecpp"}],["rect",{width:"20",height:"14",x:"2",y:"6",rx:"2",key:"i6l2r4"}]]),i=(0,d.default)("graduation-cap",[["path",{d:"M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",key:"j76jl0"}],["path",{d:"M22 10v6",key:"1lu8f3"}],["path",{d:"M6 12.5V16a6 3 0 0 0 12 0v-3.5",key:"1r8lef"}]]),j=(0,d.default)("users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]]),k=(0,d.default)("globe",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]]);var l=a.i(32860);let m=(0,d.default)("sparkles",[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]]),n=({icon:a,title:c,description:d,index:e})=>(0,b.jsxs)("div",{className:"flex gap-4 group cursor-pointer feature-card",style:{animationDelay:`${.1*e}s`},children:[(0,b.jsxs)("div",{className:"flex-shrink-0 pt-1 relative",children:[(0,b.jsxs)("div",{className:"icon-wrapper w-12 h-12 bg-gradient-to-br from-teal-500 to-emerald-500 rounded-xl flex items-center justify-center shadow-lg relative overflow-hidden",children:[(0,b.jsx)("div",{className:"absolute inset-0 bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"}),(0,b.jsx)("div",{className:"absolute inset-0 rounded-xl ripple-ring"}),(0,b.jsx)(a,{className:"w-5 h-5 text-white relative z-10 icon-bounce"}),(0,b.jsx)("div",{className:"absolute top-0 right-0 w-3 h-3 bg-white/30 rounded-bl-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"})]}),(0,b.jsx)("div",{className:"absolute top-14 left-1/2 transform -translate-x-1/2 w-0.5 h-full bg-gradient-to-b from-teal-200 to-transparent opacity-0 group-hover:opacity-50 transition-opacity duration-500"})]}),(0,b.jsxs)("div",{className:"flex-1 pb-2",children:[(0,b.jsxs)("h4",{className:"font-bold text-gray-800 text-base mb-2 group-hover:text-teal-600 transition-colors duration-300 flex items-center gap-2",children:[c,(0,b.jsx)(l.ArrowRight,{className:"w-4 h-4 opacity-0 group-hover:opacity-100 transform translate-x-0 group-hover:translate-x-1 transition-all duration-300"})]}),(0,b.jsx)("p",{className:"text-gray-600 text-sm leading-relaxed group-hover:text-gray-700 transition-colors duration-300",children:d})]})]});a.s(["default",0,()=>{let[a,d]=c.default.useState(null);return(0,b.jsxs)("div",{className:"py-20 bg-gradient-to-br from-gray-50 via-white to-teal-50/30 relative overflow-hidden",children:[(0,b.jsx)("style",{children:`
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes float {
          0%, 100% { transform: translate(0, 0) rotate(0deg); }
          33% { transform: translate(30px, -30px) rotate(5deg); }
          66% { transform: translate(-20px, 20px) rotate(-5deg); }
        }
        @keyframes pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.05); }
        }
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        @keyframes iconBounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-4px); }
        }
        @keyframes ripple {
          0% { transform: scale(0.8); opacity: 1; }
          100% { transform: scale(1.5); opacity: 0; }
        }
        @keyframes slideInLeft {
          from { opacity: 0; transform: translateX(-30px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes slideInRight {
          from { opacity: 0; transform: translateX(30px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }
        @keyframes gradientShift {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        @keyframes sparkle {
          0%, 100% { opacity: 0; transform: scale(0) rotate(0deg); }
          50% { opacity: 1; transform: scale(1) rotate(180deg); }
        }
        .feature-card {
          animation: fadeInUp 0.6s ease-out backwards;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .feature-card:hover {
          transform: translateX(8px);
        }
        .icon-wrapper {
          transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .feature-card:hover .icon-wrapper {
          transform: scale(1.1) rotate(5deg);
          box-shadow: 0 20px 25px -5px rgba(20, 184, 166, 0.4);
        }
        .icon-bounce {
          animation: iconBounce 2s ease-in-out infinite;
        }
        .ripple-ring {
          animation: ripple 2s cubic-bezier(0.4, 0, 0.2, 1) infinite;
        }
        .floating-shape {
          animation: float 20s ease-in-out infinite;
        }
        .floating-shape-delayed {
          animation: float 25s ease-in-out infinite 5s;
        }
        .floating-shape-slow {
          animation: float 30s ease-in-out infinite 10s;
        }
        .title-animate {
          animation: scaleIn 0.8s ease-out;
        }
        .subtitle-animate {
          animation: slideInLeft 0.8s ease-out 0.2s backwards;
        }
        .underline-animate {
          animation: slideInRight 0.8s ease-out 0.4s backwards;
        }
        .cta-animate {
          animation: fadeInUp 0.8s ease-out 0.6s backwards;
        }
        .gradient-text {
          background: linear-gradient(135deg, #14b8a6, #10b981, #14b8a6);
          background-size: 200% 200%;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: gradientShift 3s ease infinite;
        }
        .shimmer-effect {
          position: relative;
          overflow: hidden;
        }
        .shimmer-effect::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
          animation: shimmer 3s infinite;
        }
        .btn-primary {
          position: relative;
          overflow: hidden;
          transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .btn-primary::before {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          width: 0;
          height: 0;
          background: rgba(255, 255, 255, 0.2);
          border-radius: 50%;
          transform: translate(-50%, -50%);
          transition: width 0.6s, height 0.6s;
        }
        .btn-primary:hover::before {
          width: 300px;
          height: 300px;
        }
        .btn-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 20px 25px -5px rgba(20, 184, 166, 0.4);
        }
        .btn-secondary {
          position: relative;
          overflow: hidden;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .btn-secondary::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(20, 184, 166, 0.1), transparent);
          transition: left 0.5s;
        }
        .btn-secondary:hover::before {
          left: 100%;
        }
        .btn-secondary:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 20px -5px rgba(20, 184, 166, 0.2);
          border-color: #14b8a6;
        }
        .sparkle-icon {
          animation: sparkle 2s ease-in-out infinite;
        }
        .decorative-circle {
          position: absolute;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(20, 184, 166, 0.1), transparent);
        }
      `}),(0,b.jsxs)("div",{className:"absolute inset-0 overflow-hidden pointer-events-none",children:[(0,b.jsx)("div",{className:"absolute top-0 right-0 w-96 h-96 bg-teal-100 rounded-full opacity-20 blur-3xl floating-shape"}),(0,b.jsx)("div",{className:"absolute bottom-0 left-0 w-96 h-96 bg-green-100 rounded-full opacity-20 blur-3xl floating-shape-delayed"}),(0,b.jsx)("div",{className:"absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-100 rounded-full opacity-10 blur-3xl floating-shape-slow"}),(0,b.jsx)("div",{className:"decorative-circle",style:{width:"200px",height:"200px",top:"10%",left:"5%"}}),(0,b.jsx)("div",{className:"decorative-circle",style:{width:"150px",height:"150px",bottom:"15%",right:"8%"}})]}),(0,b.jsxs)("div",{className:"max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10",children:[(0,b.jsxs)("div",{className:"mb-16 text-center",children:[(0,b.jsxs)("div",{className:"flex items-center justify-center gap-2 mb-3 subtitle-animate",children:[(0,b.jsx)(m,{className:"w-4 h-4 text-teal-600 sparkle-icon"}),(0,b.jsx)("p",{className:"text-teal-600 italic font-medium",children:"Get to Know About Us"}),(0,b.jsx)(m,{className:"w-4 h-4 text-teal-600 sparkle-icon",style:{animationDelay:"1s"}})]}),(0,b.jsxs)("h2",{className:"text-5xl md:text-6xl font-bold text-gray-800 mb-4 title-animate",children:["Why ",(0,b.jsx)("span",{className:"gradient-text",children:"REC?"})]}),(0,b.jsxs)("div",{className:"flex items-center justify-center gap-3 underline-animate",children:[(0,b.jsx)("div",{className:"h-1 w-20 bg-gradient-to-r from-transparent to-teal-500 rounded-full"}),(0,b.jsx)("div",{className:"h-2 w-2 bg-teal-500 rounded-full"}),(0,b.jsx)("div",{className:"h-1 w-20 bg-gradient-to-l from-transparent to-teal-500 rounded-full"})]}),(0,b.jsx)("p",{className:"text-gray-600 mt-6 max-w-2xl mx-auto leading-relaxed subtitle-animate",style:{animationDelay:"0.3s"},children:"Discover what makes us the premier choice for environmental consultancy services"})]}),(0,b.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8 mb-12",children:[{icon:e,title:"Environmental Impact:",description:"REC play a crucial role in helping businesses minimize their environmental impact through expert advice and solutions.",index:0},{icon:f,title:"Sustainable Development:",description:"We assist clients in adopting sustainable practices, incorporating eco-friendly technologies and energy-efficient processes.",index:1},{icon:g,title:"Problem Solving:",description:"Our consultants assess environmental issues and develop innovative solutions to environmental challenges.",index:2},{icon:h,title:"Diverse Projects:",description:"We cover environmental impact assessments, site remediation, water resource management, and renewable energy projects.",index:3},{icon:i,title:"Educational Role:",description:"We educate clients about environmental issues and best practices, promoting environmental stewardship.",index:4},{icon:j,title:"Collaboration:",description:"We collaborate with experts from diverse fields, fostering a collaborative work environment for continuous learning.",index:5},{icon:k,title:"Global Relevance:",description:"We work on international projects, addressing environmental challenges and contributing to global sustainability efforts.",index:6}].map((a,c)=>(0,b.jsx)(n,{...a,index:c},c))}),(0,b.jsxs)("div",{className:"flex flex-col sm:flex-row gap-4 justify-center items-center cta-animate",children:[(0,b.jsxs)("button",{className:"btn-primary bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white px-8 py-3.5 rounded-xl font-semibold shadow-lg flex items-center gap-2 group relative z-10",onMouseEnter:()=>d("learn"),onMouseLeave:()=>d(null),children:[(0,b.jsx)("span",{className:"relative z-10",children:"Learn More"}),(0,b.jsx)(l.ArrowRight,{className:"w-5 h-5 relative z-10 transition-transform duration-300 group-hover:translate-x-1"})]}),(0,b.jsxs)("button",{className:"btn-secondary border-2 border-teal-600 text-teal-600 hover:text-teal-700 px-8 py-3.5 rounded-xl font-semibold flex items-center gap-2 group bg-white relative z-10",onMouseEnter:()=>d("contact"),onMouseLeave:()=>d(null),children:[(0,b.jsx)("span",{className:"relative z-10",children:"Contact Us"}),(0,b.jsx)(l.ArrowRight,{className:"w-5 h-5 relative z-10 transition-transform duration-300 group-hover:translate-x-1"})]})]})]})]})}],4582)}];

//# sourceMappingURL=_0cae4b4b._.js.map