(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_f249eb4c._.js",
  "static/chunks/node_modules_03a3239b._.js"
],
    source: "dynamic"
});
