(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_862e1136._.js",
  "static/chunks/node_modules_7453fe05._.js"
],
    source: "dynamic"
});
